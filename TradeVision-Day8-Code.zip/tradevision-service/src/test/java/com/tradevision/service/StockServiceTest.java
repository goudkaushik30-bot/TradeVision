package com.tradevision.service;

import com.tradevision.common.dto.StockPriceDto;
import com.tradevision.repository.StockPriceRepository;
import com.tradevision.repository.entity.StockPrice;
import com.tradevision.service.impl.StockServiceImpl;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * StockServiceTest — Day 8 TradeVision
 *
 * WHY MOCKITO?
 * In unit tests, we test ONE class in isolation.
 * StockServiceImpl depends on StockPriceRepository (database).
 * We don't want a real database in unit tests — slow, brittle.
 *
 * Mockito creates a "mock" (fake) StockPriceRepository.
 * We tell the mock what to return: when().thenReturn()
 * The service runs against the mock — no DB, no network.
 * Tests run in milliseconds, not seconds.
 *
 * WHY @ExtendWith(MockitoExtension)?
 * Enables Mockito annotations: @Mock, @InjectMocks
 * @Mock creates the fake dependency
 * @InjectMocks creates real instance with mocks injected
 *
 * WHY AssertJ over JUnit assertions?
 * JUnit: assertEquals(expected, actual) — confusing order
 * AssertJ: assertThat(actual).isEqualTo(expected) — reads naturally
 * Also: assertThat(list).hasSize(5).contains("AAPL") — fluent chaining
 *
 * WHY test BigDecimal carefully?
 * BigDecimal("191.3420").equals(BigDecimal("191.342")) = FALSE
 * Different scale! Use compareTo() or isEqualByComparingTo() in tests.
 */
@ExtendWith(MockitoExtension.class)
class StockServiceTest {

    @Mock
    private StockPriceRepository stockPriceRepository;

    @InjectMocks
    private StockServiceImpl stockService;

    @Test
    @DisplayName("getLatestPrice returns correct DTO for valid ticker")
    void getLatestPrice_validTicker_returnsDto() {
        // ARRANGE
        StockPrice mockPrice = new StockPrice();
        mockPrice.setTicker("AAPL");
        mockPrice.setCompanyName("Apple Inc.");
        mockPrice.setCurrentPrice(new BigDecimal("191.3420"));
        mockPrice.setChangePercent(new BigDecimal("0.97"));
        mockPrice.setVolume(47823610L);

        when(stockPriceRepository.findTopByTickerOrderByRecordedAtDesc("AAPL"))
            .thenReturn(Optional.of(mockPrice));

        // ACT
        StockPriceDto result = stockService.getLatestPrice("AAPL");

        // ASSERT
        assertThat(result).isNotNull();
        assertThat(result.getTicker()).isEqualTo("AAPL");
        assertThat(result.getCurrentPrice())
            .isEqualByComparingTo(new BigDecimal("191.3420"));
        assertThat(result.getPriceDirection()).isEqualTo("UP");

        verify(stockPriceRepository, times(1))
            .findTopByTickerOrderByRecordedAtDesc("AAPL");
    }

    @Test
    @DisplayName("getLatestPrice throws exception for unknown ticker")
    void getLatestPrice_unknownTicker_throwsException() {
        when(stockPriceRepository.findTopByTickerOrderByRecordedAtDesc("FAKE"))
            .thenReturn(Optional.empty());

        assertThatThrownBy(() -> stockService.getLatestPrice("FAKE"))
            .isInstanceOf(RuntimeException.class)
            .hasMessageContaining("Ticker not found: FAKE");
    }

    @Test
    @DisplayName("price direction is DOWN when changePercent is negative")
    void priceDirection_negative_returnsDown() {
        StockPrice mockPrice = new StockPrice();
        mockPrice.setTicker("TSLA");
        mockPrice.setCompanyName("Tesla Inc.");
        mockPrice.setCurrentPrice(new BigDecimal("243.8800"));
        mockPrice.setChangePercent(new BigDecimal("-1.86"));
        mockPrice.setVolume(63412780L);

        when(stockPriceRepository.findTopByTickerOrderByRecordedAtDesc("TSLA"))
            .thenReturn(Optional.of(mockPrice));

        StockPriceDto result = stockService.getLatestPrice("TSLA");

        assertThat(result.getPriceDirection()).isEqualTo("DOWN");
        assertThat(result.getChangePercent())
            .isEqualByComparingTo(new BigDecimal("-1.86"));
    }
}
