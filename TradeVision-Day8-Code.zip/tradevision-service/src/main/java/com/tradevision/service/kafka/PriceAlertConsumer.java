package com.tradevision.service.kafka;

import com.tradevision.common.dto.kafka.PriceAlertEvent;
import com.tradevision.repository.PriceAlertRepository;
import com.tradevision.repository.entity.PriceAlert;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

/**
 * PriceAlertConsumer — Day 6 TradeVision
 *
 * WHY @KafkaListener?
 * This annotation creates a background thread that continuously
 * polls the Kafka "price-alerts" topic for new messages.
 * groupId = "alert-service" — this consumer group tracks its own offset.
 * Multiple instances of this service = Kafka load-balances partitions.
 *
 * WHY MANUAL ACKNOWLEDGMENT (AckMode.MANUAL)?
 * Default: Spring auto-commits offset BEFORE processing.
 * Risk: app crashes after commit but before saving to DB → message LOST.
 *
 * Manual: we commit offset ONLY AFTER successful DB save.
 * If processing fails, offset is NOT committed.
 * Kafka replays the message on next consumer restart.
 * At-least-once delivery guarantee.
 * Non-negotiable in financial systems.
 *
 * WHY ConsumerRecord wrapper?
 * Gives us access to metadata: partition, offset, timestamp, headers.
 * We log partition+offset for full traceability — every alert
 * can be traced back to its exact Kafka position for auditing.
 */
@Service
public class PriceAlertConsumer {

    private static final Logger log = LoggerFactory.getLogger(PriceAlertConsumer.class);

    @Autowired
    private PriceAlertRepository alertRepository;

    @KafkaListener(
        topics = "price-alerts",
        groupId = "alert-service",
        containerFactory = "kafkaListenerContainerFactory"
    )
    public void consumeAlert(
            ConsumerRecord<String, PriceAlertEvent> record,
            Acknowledgment ack) {

        PriceAlertEvent event = record.value();

        log.info("Consuming alert → partition={} offset={} ticker={} type={}",
            record.partition(), record.offset(),
            event.getTicker(), event.getAlertType());

        try {
            // Mark the alert as triggered in DB
            alertRepository.findByTickerAndStatus(event.getTicker(), "ACTIVE")
                .stream()
                .filter(a -> shouldTrigger(a, event))
                .forEach(alert -> {
                    alert.setStatus("TRIGGERED");
                    alert.setTriggeredAtPrice(event.getTriggeredPrice());
                    alert.setTriggeredAt(event.getOccurredAt());
                    alertRepository.save(alert);
                    log.info("Alert TRIGGERED: userId={} ticker={} at ${}",
                        alert.getUserId(), event.getTicker(),
                        event.getTriggeredPrice());
                });

            // Commit offset ONLY after successful processing
            ack.acknowledge();

        } catch (Exception e) {
            log.error("Failed to process alert event for {}: {}",
                event.getTicker(), e.getMessage());
            // Do NOT acknowledge — Kafka will redeliver
        }
    }

    private boolean shouldTrigger(PriceAlert alert, PriceAlertEvent event) {
        if ("ABOVE".equals(alert.getAlertType())) {
            return event.getTriggeredPrice()
                .compareTo(alert.getThresholdPrice()) >= 0;
        } else {
            return event.getTriggeredPrice()
                .compareTo(alert.getThresholdPrice()) <= 0;
        }
    }
}
