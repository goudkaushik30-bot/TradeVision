package com.tradevision.service.impl;

import com.tradevision.common.event.PriceAlertEvent;
import com.tradevision.repository.PriceAlertRepository;
import com.tradevision.repository.entity.PriceAlert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;

/**
 * KafkaAlertConsumer — Day 6 TradeVision
 *
 * WHAT DOES A KAFKA CONSUMER DO?
 * It SUBSCRIBES to a topic and processes messages as they arrive.
 * Decoupled from the producer — runs in its own thread.
 * If the consumer is slow or down, messages wait in Kafka.
 * When it recovers, it processes the backlog. No data lost.
 *
 * WHY @KafkaListener?
 * Spring's annotation that wires this method to the Kafka consumer loop.
 * groupId = "alert-service-group"
 * Consumer groups allow multiple instances to share the load —
 * each partition is consumed by exactly ONE instance in the group.
 * Scale horizontally just by deploying more instances.
 *
 * WHY groupId matters:
 * If you have 3 partitions and 3 consumer instances in the same group,
 * each instance handles 1 partition → perfect parallel processing.
 * This is how Fidelity handles millions of alerts at scale.
 *
 * WHAT HAPPENS WHEN ALERT FIRES:
 * 1. Consume event from Kafka topic
 * 2. Update PriceAlert status → TRIGGERED in PostgreSQL
 * 3. Record exact price that triggered the alert
 * 4. (Day 7) Send email/SMS/push notification to user
 *
 * WHY @Header for partition and offset?
 * Kafka metadata — which partition and message offset.
 * Critical for debugging: "Alert 47 fired at partition 2, offset 1823"
 * You can replay from any offset if processing fails.
 */
@Service
public class KafkaAlertConsumer {

    private static final Logger log = LoggerFactory.getLogger(KafkaAlertConsumer.class);

    @Autowired
    private PriceAlertRepository alertRepository;

    @KafkaListener(
        topics = "price-alerts",
        groupId = "alert-service-group",
        containerFactory = "kafkaListenerContainerFactory"
    )
    public void consumeAlertEvent(
            @Payload PriceAlertEvent event,
            @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
            @Header(KafkaHeaders.OFFSET) long offset) {

        log.info("Consumed alert event | ticker={} | type={} | price={} | partition={} | offset={}",
            event.getTicker(), event.getAlertType(),
            event.getTriggeredPrice(), partition, offset);

        // Update alert status to TRIGGERED in PostgreSQL
        alertRepository.findById(event.getAlertId()).ifPresent(alert -> {
            alert.setStatus("TRIGGERED");
            alert.setTriggeredAtPrice(event.getTriggeredPrice());
            alert.setTriggeredAt(LocalDateTime.now());
            alertRepository.save(alert);

            log.info("Alert {} triggered for user {} | {} {} at ${}",
                alert.getId(), alert.getUserId(),
                alert.getTicker(), alert.getAlertType(),
                event.getTriggeredPrice());

            // TODO Day 7: Send email notification via Spring Mail
            // TODO Day 7: Send push notification via WebSocket
        });
    }
}
