package com.tradevision.service.impl;

import com.tradevision.common.event.PriceAlertEvent;
import com.tradevision.repository.PriceAlertRepository;
import com.tradevision.repository.StockPriceRepository;
import com.tradevision.repository.entity.PriceAlert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.List;

/**
 * AlertServiceImpl — Day 6 TradeVision
 *
 * WHY CHECK ALERTS ON A SCHEDULE vs in-line with price updates?
 * Separation of concerns. Price update = one responsibility.
 * Alert checking = another responsibility.
 * If alert checking fails, price updates still work.
 * If alert checking is slow, it doesn't block price ingestion.
 * This is the Single Responsibility Principle applied to services.
 *
 * THE ALERT CHECK FLOW:
 * 1. Every 35 seconds (5s after price update at 30s)
 * 2. Load all ACTIVE alerts from PostgreSQL
 * 3. Get latest price for each alert's ticker
 * 4. Check if threshold is crossed
 * 5. If YES → publish to Kafka → consumer handles notification
 *
 * WHY 35 SECONDS (not 30)?
 * Price updates run at 30s intervals.
 * We wait 5 extra seconds to ensure new prices are committed
 * to PostgreSQL before we check them. Simple but effective.
 * In production we'd use Kafka events to trigger checks instead.
 *
 * ABOVE alert: fire when price > threshold
 * BELOW alert: fire when price < threshold
 */
@Service
public class AlertServiceImpl {

    @Autowired
    private PriceAlertRepository alertRepository;

    @Autowired
    private StockPriceRepository stockPriceRepository;

    @Autowired
    private KafkaAlertProducer kafkaProducer;

    @Scheduled(fixedDelay = 35000)
    public void checkAlerts() {
        List<PriceAlert> activeAlerts = alertRepository.findByStatus("ACTIVE");

        for (PriceAlert alert : activeAlerts) {
            stockPriceRepository
                .findTopByTickerOrderByRecordedAtDesc(alert.getTicker())
                .ifPresent(latestPrice -> {
                    BigDecimal current = latestPrice.getCurrentPrice();
                    BigDecimal threshold = alert.getThresholdPrice();
                    boolean triggered = false;

                    if ("ABOVE".equals(alert.getAlertType()) &&
                        current.compareTo(threshold) > 0) {
                        triggered = true;
                    } else if ("BELOW".equals(alert.getAlertType()) &&
                               current.compareTo(threshold) < 0) {
                        triggered = true;
                    }

                    if (triggered) {
                        PriceAlertEvent event = new PriceAlertEvent(
                            alert.getTicker(),
                            latestPrice.getCompanyName(),
                            current, threshold,
                            alert.getAlertType(),
                            alert.getUserId(),
                            alert.getId()
                        );
                        kafkaProducer.publishAlertEvent(event);
                    }
                });
        }
    }

    public PriceAlert createAlert(Long userId, String ticker,
                                   BigDecimal threshold, String type) {
        PriceAlert alert = new PriceAlert();
        alert.setUserId(userId);
        alert.setTicker(ticker);
        alert.setThresholdPrice(threshold);
        alert.setAlertType(type.toUpperCase());
        return alertRepository.save(alert);
    }

    public List<PriceAlert> getUserAlerts(Long userId) {
        return alertRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }
}
