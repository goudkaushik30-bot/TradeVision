package com.tradevision.service.impl;

import com.tradevision.common.dto.PortfolioDto;
import com.tradevision.common.dto.PortfolioDto.HoldingDto;
import com.tradevision.repository.PortfolioHoldingRepository;
import com.tradevision.repository.StockPriceRepository;
import com.tradevision.repository.entity.PortfolioHolding;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

/**
 * PortfolioServiceImpl — Day 5 TradeVision
 *
 * P&L CALCULATION LOGIC:
 * costBasis       = quantity × avgCostBasis
 * currentValue    = quantity × currentPrice
 * unrealisedPnl   = currentValue - costBasis
 * unrealisedPnl%  = (unrealisedPnl / costBasis) × 100
 *
 * WHY @Transactional?
 * When we update P&L across multiple holdings, ALL updates
 * must succeed or ALL must fail. This is ACID compliance.
 * If the app crashes mid-update, no partial state is saved.
 * Critical in any financial data system.
 *
 * WHY separate totalInvested vs totalValue?
 * totalInvested = what the user PAID (historical, fixed)
 * totalValue    = what it's worth NOW (changes with market)
 * The difference IS the unrealised P&L.
 * Every portfolio dashboard in fintech shows both.
 */
@Service
public class PortfolioServiceImpl {

    @Autowired
    private PortfolioHoldingRepository portfolioRepo;

    @Autowired
    private StockPriceRepository stockPriceRepo;

    public PortfolioDto getPortfolio(Long userId) {
        List<PortfolioHolding> holdings = portfolioRepo.findByUserId(userId);

        List<HoldingDto> holdingDtos = holdings.stream().map(h -> {
            BigDecimal currentPrice = stockPriceRepo
                .findTopByTickerOrderByRecordedAtDesc(h.getTicker())
                .map(p -> p.getCurrentPrice())
                .orElse(h.getAvgCostBasis());

            BigDecimal costBasis    = h.getQuantity().multiply(h.getAvgCostBasis());
            BigDecimal currentValue = h.getQuantity().multiply(currentPrice);
            BigDecimal pnl          = currentValue.subtract(costBasis);
            BigDecimal pnlPct       = pnl.divide(costBasis, 4, RoundingMode.HALF_UP)
                                         .multiply(new BigDecimal("100"))
                                         .setScale(2, RoundingMode.HALF_UP);

            return new HoldingDto(
                h.getTicker(), h.getCompanyName(),
                h.getQuantity(), h.getAvgCostBasis(),
                currentPrice, currentValue, pnl, pnlPct
            );
        }).toList();

        BigDecimal totalValue     = holdingDtos.stream()
            .map(HoldingDto::getCurrentValue)
            .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalInvested  = holdings.stream()
            .map(h -> h.getQuantity().multiply(h.getAvgCostBasis()))
            .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalPnl       = totalValue.subtract(totalInvested);
        BigDecimal totalPnlPct    = totalInvested.compareTo(BigDecimal.ZERO) == 0
            ? BigDecimal.ZERO
            : totalPnl.divide(totalInvested, 4, RoundingMode.HALF_UP)
                       .multiply(new BigDecimal("100"))
                       .setScale(2, RoundingMode.HALF_UP);

        return new PortfolioDto(totalValue, totalInvested, totalPnl, totalPnlPct, holdingDtos);
    }

    @Transactional
    public void addOrUpdateHolding(Long userId, String ticker,
                                    String companyName,
                                    BigDecimal quantity,
                                    BigDecimal purchasePrice) {
        portfolioRepo.findByUserIdAndTicker(userId, ticker)
            .ifPresentOrElse(existing -> {
                // Average down/up cost basis
                BigDecimal totalShares = existing.getQuantity().add(quantity);
                BigDecimal totalCost   = existing.getQuantity()
                    .multiply(existing.getAvgCostBasis())
                    .add(quantity.multiply(purchasePrice));
                BigDecimal newAvg      = totalCost.divide(totalShares, 4, RoundingMode.HALF_UP);

                existing.setQuantity(totalShares);
                existing.setAvgCostBasis(newAvg);
                portfolioRepo.save(existing);
            }, () -> {
                PortfolioHolding h = new PortfolioHolding();
                h.setUserId(userId);
                h.setTicker(ticker);
                h.setCompanyName(companyName);
                h.setQuantity(quantity);
                h.setAvgCostBasis(purchasePrice);
                portfolioRepo.save(h);
            });
    }
}
