package com.tradevision.service.impl;

import com.tradevision.repository.UserRepository;
import com.tradevision.repository.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * UserDetailsServiceImpl — Day 3 TradeVision
 *
 * WHY does Spring Security need this?
 * Spring Security needs to know HOW to load a user from our database.
 * It doesn't know about our User entity or UserRepository.
 * This class is the bridge — it implements Spring's UserDetailsService
 * interface so Spring Security knows exactly how to find our users.
 *
 * THE FLOW:
 * 1. JWT filter extracts username from token
 * 2. Calls loadUserByUsername(username)
 * 3. We hit PostgreSQL via UserRepository
 * 4. Map our User entity → Spring's UserDetails object
 * 5. Spring Security uses UserDetails to verify roles, status, etc.
 *
 * WHY SimpleGrantedAuthority?
 * Spring Security works with "authorities" (permissions/roles).
 * We store roles as strings in DB ("ROLE_USER", "ROLE_ADMIN").
 * SimpleGrantedAuthority wraps that string into what Spring expects.
 * This enables @PreAuthorize("hasRole('ADMIN')") checks across the app.
 */
@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException {

        User user = userRepository.findByUsername(username)
            .orElseThrow(() ->
                new UsernameNotFoundException(
                    "User not found: " + username
                )
            );

        return new org.springframework.security.core.userdetails.User(
            user.getUsername(),
            user.getPassword(),
            user.getEnabled(),
            true, true, true,
            List.of(new SimpleGrantedAuthority(user.getRole()))
        );
    }
}
