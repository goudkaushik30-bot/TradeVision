package com.tradevision.service.impl;

import com.tradevision.common.dto.StockPriceDto;
import com.tradevision.repository.StockPriceRepository;
import com.tradevision.repository.entity.StockPrice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

/**
 * StockServiceImpl — Day 4 TradeVision
 *
 * WHY @Cacheable with Redis?
 * Stock prices are read THOUSANDS of times per second by multiple users.
 * Without caching, every read hits PostgreSQL — the DB gets hammered.
 * With Redis cache:
 *   - First call: hits PostgreSQL, stores result in Redis (milliseconds)
 *   - Next 1000 calls: served from Redis memory (microseconds)
 * This is how Fidelity, USAA serve millions of price requests daily.
 *
 * WHY @Scheduled for price simulation?
 * In production, we'd connect to a real market data feed (Polygon.io, Alpha Vantage).
 * For Day 4, we simulate price movement using a random walk algorithm —
 * the same statistical model used in quantitative finance (Brownian motion).
 * This lets us build and test the full pipeline without a paid API key.
 *
 * WHY @CacheEvict after price update?
 * When we store a new price, the cached value is stale.
 * @CacheEvict tells Redis to invalidate the cache for that ticker.
 * Next read will fetch fresh data from PostgreSQL and re-cache.
 * Cache invalidation is one of the hardest problems in distributed systems.
 *
 * RANDOM WALK ALGORITHM:
 * Price(t+1) = Price(t) * (1 + random_factor)
 * where random_factor is a small random number between -0.02 and +0.02
 * This mimics realistic stock price movement (±2% per tick).
 */
@Service
public class StockServiceImpl {

    @Autowired
    private StockPriceRepository stockPriceRepository;

    // Seed data — initial prices for tracked stocks
    private static final Map<String, Object[]> STOCK_SEEDS = new LinkedHashMap<>();
    static {
        STOCK_SEEDS.put("AAPL",  new Object[]{"Apple Inc.",       new BigDecimal("189.50")});
        STOCK_SEEDS.put("GOOGL", new Object[]{"Alphabet Inc.",    new BigDecimal("141.80")});
        STOCK_SEEDS.put("MSFT",  new Object[]{"Microsoft Corp.",  new BigDecimal("378.90")});
        STOCK_SEEDS.put("AMZN",  new Object[]{"Amazon.com Inc.",  new BigDecimal("178.25")});
        STOCK_SEEDS.put("TSLA",  new Object[]{"Tesla Inc.",       new BigDecimal("248.50")});
        STOCK_SEEDS.put("JPM",   new Object[]{"JPMorgan Chase",   new BigDecimal("196.40")});
        STOCK_SEEDS.put("BAC",   new Object[]{"Bank of America",  new BigDecimal("38.20")});
        STOCK_SEEDS.put("GS",    new Object[]{"Goldman Sachs",    new BigDecimal("451.30")});
    }

    // In-memory price state for simulation
    private final Map<String, BigDecimal> currentPrices = new LinkedHashMap<>();

    /**
     * Get latest price for a single ticker
     * @Cacheable: "stock:AAPL" key in Redis → instant response
     */
    @Cacheable(value = "stockPrices", key = "#ticker")
    public StockPriceDto getLatestPrice(String ticker) {
        return stockPriceRepository
            .findTopByTickerOrderByRecordedAtDesc(ticker.toUpperCase())
            .map(this::toDto)
            .orElseThrow(() ->
                new RuntimeException("Ticker not found: " + ticker));
    }

    /**
     * Get all latest prices — for the dashboard market overview
     */
    @Cacheable(value = "allStockPrices")
    public List<StockPriceDto> getAllLatestPrices() {
        return stockPriceRepository.findLatestPricesForAllTickers()
            .stream()
            .map(this::toDto)
            .toList();
    }

    /**
     * Simulate price updates every 30 seconds
     * WHY @Scheduled(fixedDelay = 30000)?
     * fixedDelay = wait 30s AFTER previous execution completes.
     * fixedRate = every 30s regardless — can overlap if slow.
     * For financial data, fixedDelay is safer — no overlapping updates.
     */
    @Scheduled(fixedDelay = 30000)
    @CacheEvict(value = {"stockPrices", "allStockPrices"}, allEntries = true)
    public void simulatePriceUpdates() {
        Random random = new Random();

        STOCK_SEEDS.forEach((ticker, seedData) -> {
            BigDecimal basePrice = currentPrices.getOrDefault(
                ticker, (BigDecimal) seedData[1]
            );

            // Random walk: ±2% movement
            double changeFactor = 1 + (random.nextDouble() * 0.04 - 0.02);
            BigDecimal newPrice = basePrice
                .multiply(new BigDecimal(changeFactor))
                .setScale(4, RoundingMode.HALF_UP);

            BigDecimal changePercent = newPrice.subtract(basePrice)
                .divide(basePrice, 4, RoundingMode.HALF_UP)
                .multiply(new BigDecimal("100"))
                .setScale(2, RoundingMode.HALF_UP);

            currentPrices.put(ticker, newPrice);

            StockPrice price = new StockPrice();
            price.setTicker(ticker);
            price.setCompanyName((String) seedData[0]);
            price.setCurrentPrice(newPrice);
            price.setOpenPrice((BigDecimal) seedData[1]);
            price.setHighPrice(newPrice.max((BigDecimal) seedData[1]));
            price.setLowPrice(newPrice.min((BigDecimal) seedData[1]));
            price.setPreviousClose((BigDecimal) seedData[1]);
            price.setChangePercent(changePercent);
            price.setVolume(1000000L + random.nextInt(9000000));

            stockPriceRepository.save(price);
        });
    }

    private StockPriceDto toDto(StockPrice s) {
        return new StockPriceDto(
            s.getTicker(), s.getCompanyName(),
            s.getCurrentPrice(), s.getOpenPrice(),
            s.getHighPrice(), s.getLowPrice(),
            s.getChangePercent(), s.getVolume(),
            s.getRecordedAt()
        );
    }
}
