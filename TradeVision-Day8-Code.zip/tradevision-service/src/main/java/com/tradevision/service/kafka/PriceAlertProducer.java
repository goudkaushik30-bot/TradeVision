package com.tradevision.service.kafka;

import com.tradevision.common.dto.kafka.PriceAlertEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import java.util.concurrent.CompletableFuture;

/**
 * PriceAlertProducer — Day 6 TradeVision
 *
 * WHY KafkaTemplate?
 * Spring's KafkaTemplate abstracts the raw Kafka producer API.
 * Without it, we'd manually create ProducerRecord objects,
 * handle serialisation, manage callbacks. KafkaTemplate does all of it.
 *
 * WHY CompletableFuture for send result?
 * Kafka send is asynchronous — the message goes to a local buffer first.
 * CompletableFuture lets us attach a callback: whenComplete().
 * We log success (partition + offset) or failure without blocking.
 *
 * WHAT IS A PARTITION?
 * Kafka topics are split into partitions for parallelism.
 * Messages with the same key go to the same partition = order guaranteed.
 * We use ticker as the key — all AAPL events are ordered.
 * Different tickers can process in parallel across partitions.
 *
 * WHAT IS AN OFFSET?
 * Every message in a partition gets a sequential offset number.
 * Consumers track their offset — if they restart, they resume
 * from last committed offset. Zero message loss guaranteed.
 * This is why Kafka is used for financial event streams.
 *
 * DEAD LETTER QUEUE (DLQ):
 * If publishing fails after retries, we log to DLQ topic.
 * Ops team can inspect and replay failed events manually.
 * Same pattern we used at Fidelity for failed ETax events.
 */
@Service
public class PriceAlertProducer {

    private static final Logger log = LoggerFactory.getLogger(PriceAlertProducer.class);
    private static final String TOPIC = "price-alerts";
    private static final String DLQ_TOPIC = "price-alerts-dlq";

    @Autowired
    private KafkaTemplate<String, PriceAlertEvent> kafkaTemplate;

    public void publishAlert(PriceAlertEvent event) {
        // Key = ticker ensures ordering per stock
        CompletableFuture<SendResult<String, PriceAlertEvent>> future =
            kafkaTemplate.send(TOPIC, event.getTicker(), event);

        future.whenComplete((result, ex) -> {
            if (ex == null) {
                log.info("Alert published → topic={} partition={} offset={} ticker={}",
                    TOPIC,
                    result.getRecordMetadata().partition(),
                    result.getRecordMetadata().offset(),
                    event.getTicker());
            } else {
                log.error("Failed to publish alert for {} — routing to DLQ: {}",
                    event.getTicker(), ex.getMessage());
                // Route to Dead Letter Queue
                kafkaTemplate.send(DLQ_TOPIC, event.getTicker(), event);
            }
        });
    }
}
