package com.tradevision.service.impl;

import com.tradevision.common.event.PriceAlertEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import java.util.concurrent.CompletableFuture;

/**
 * KafkaAlertProducer — Day 6 TradeVision
 *
 * WHAT DOES A KAFKA PRODUCER DO?
 * It PUBLISHES messages to a Kafka topic.
 * Think of it as a radio broadcaster — it sends the signal,
 * doesn't care who's listening or how many consumers there are.
 *
 * WHY KafkaTemplate<String, PriceAlertEvent>?
 * KafkaTemplate is Spring Kafka's abstraction over the raw Kafka API.
 * String = the message KEY (we use ticker symbol — e.g. "AAPL")
 * PriceAlertEvent = the message VALUE (the full event object)
 *
 * WHY USE THE TICKER AS THE KEY?
 * Kafka partitions messages by key.
 * All AAPL events go to the same partition → consumed in ORDER.
 * This guarantees alert events for the same stock are processed
 * sequentially — preventing a BELOW alert firing after an ABOVE alert
 * on the same tick due to out-of-order processing.
 * This is partition-based ordering — a core Kafka concept.
 *
 * WHY CompletableFuture for send result?
 * Kafka send is async. We don't block the price update thread.
 * We attach a callback to handle success/failure without blocking.
 * Failed sends are logged — in production, we'd retry or dead-letter.
 *
 * TOPIC: "price-alerts" (defined in application.yml)
 */
@Service
public class KafkaAlertProducer {

    private static final Logger log = LoggerFactory.getLogger(KafkaAlertProducer.class);
    private static final String TOPIC = "price-alerts";

    @Autowired
    private KafkaTemplate<String, PriceAlertEvent> kafkaTemplate;

    public void publishAlertEvent(PriceAlertEvent event) {
        // Key = ticker → ensures ordered processing per stock
        CompletableFuture<SendResult<String, PriceAlertEvent>> future =
            kafkaTemplate.send(TOPIC, event.getTicker(), event);

        future.whenComplete((result, ex) -> {
            if (ex == null) {
                log.info("Alert published to Kafka | ticker={} | offset={} | partition={}",
                    event.getTicker(),
                    result.getRecordMetadata().offset(),
                    result.getRecordMetadata().partition());
            } else {
                log.error("Failed to publish alert | ticker={} | error={}",
                    event.getTicker(), ex.getMessage());
                // In production: send to dead-letter topic for retry
            }
        });
    }
}
