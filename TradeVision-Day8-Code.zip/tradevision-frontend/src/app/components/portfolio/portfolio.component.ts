import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { interval, Subscription } from 'rxjs';
import { switchMap } from 'rxjs/operators';

/**
 * PortfolioComponent — Day 5 TradeVision
 *
 * WHY RxJS interval + switchMap?
 * We want live P&L updates every 30 seconds without the user refreshing.
 * interval(30000) emits a value every 30s.
 * switchMap cancels previous HTTP request if a new one arrives.
 * This prevents race conditions where slow responses arrive out of order.
 *
 * WHY OnDestroy + unsubscribe?
 * Angular components can be destroyed (user navigates away).
 * If we don't unsubscribe, the interval keeps running in background.
 * That's a memory leak. Always unsubscribe on destroy.
 * This is a common bug in Angular apps — we do it right from day one.
 */
@Component({
  selector: 'app-portfolio',
  templateUrl: './portfolio.component.html',
  styleUrls: ['./portfolio.component.scss']
})
export class PortfolioComponent implements OnInit, OnDestroy {

  portfolio: any = null;
  loading = true;
  error = '';
  private refreshSub: Subscription;

  private headers = new HttpHeaders({
    'Authorization': `Bearer ${localStorage.getItem('tv_token')}`
  });

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loadPortfolio();

    // Auto-refresh every 30 seconds
    this.refreshSub = interval(30000)
      .pipe(switchMap(() => this.fetchPortfolio()))
      .subscribe(data => this.portfolio = data);
  }

  loadPortfolio(): void {
    this.fetchPortfolio().subscribe({
      next: (data) => { this.portfolio = data; this.loading = false; },
      error: (err) => { this.error = 'Failed to load portfolio'; this.loading = false; }
    });
  }

  fetchPortfolio() {
    return this.http.get('/api/v1/portfolio/1', { headers: this.headers });
  }

  isProfitable(pnl: number): boolean {
    return pnl >= 0;
  }

  ngOnDestroy(): void {
    if (this.refreshSub) this.refreshSub.unsubscribe();
  }
}
