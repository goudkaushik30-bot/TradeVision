import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

/**
 * AlertsComponent — Day 6 TradeVision
 *
 * WHY WebSocket for real-time alert notifications?
 * HTTP polling (asking server "any new alerts?" every N seconds)
 * is wasteful — mostly empty responses.
 *
 * WebSocket: persistent bidirectional connection.
 * Server PUSHES alert to client the moment Kafka consumer processes it.
 * Sub-second latency from price crossing threshold to user seeing alert.
 *
 * For Day 6 we use HTTP polling as a stepping stone.
 * WebSocket integration comes Day 8 with STOMP over WebSocket.
 * This is how we'd build it in production too — HTTP first,
 * optimise to WebSocket when the feature is stable.
 */
@Component({
  selector: 'app-alerts',
  templateUrl: './alerts.component.html',
  styleUrls: ['./alerts.component.scss']
})
export class AlertsComponent implements OnInit {

  alerts: any[] = [];
  loading = true;
  newAlert = { ticker: '', thresholdPrice: null, alertType: 'ABOVE', userId: 1 };

  private headers = new HttpHeaders({
    'Authorization': `Bearer ${localStorage.getItem('tv_token')}`
  });

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loadAlerts();
  }

  loadAlerts(): void {
    this.http.get('/api/v1/alerts/1', { headers: this.headers })
      .subscribe({
        next: (data: any) => { this.alerts = data; this.loading = false; },
        error: () => { this.loading = false; }
      });
  }

  createAlert(): void {
    this.http.post('/api/v1/alerts', this.newAlert, { headers: this.headers })
      .subscribe(() => { this.loadAlerts(); this.resetForm(); });
  }

  cancelAlert(id: number): void {
    this.http.delete(`/api/v1/alerts/${id}`, { headers: this.headers })
      .subscribe(() => this.loadAlerts());
  }

  resetForm(): void {
    this.newAlert = { ticker: '', thresholdPrice: null, alertType: 'ABOVE', userId: 1 };
  }

  getStatusColor(status: string): string {
    return status === 'TRIGGERED' ? '#4ade80' :
           status === 'ACTIVE'    ? '#fbbf24' : '#64748b';
  }
}
