package com.tradevision.common.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * StockPriceDto — Day 4 TradeVision
 *
 * WHY a separate DTO for API response?
 * The StockPrice entity has database-specific fields (id, indexes etc).
 * The client only needs trading-relevant data.
 * DTOs also let us add computed fields like priceDirection
 * without polluting the database entity.
 *
 * WHY include priceDirection?
 * Frontend Angular component needs to know UP/DOWN/FLAT
 * to show green/red arrows. Computed once on server,
 * not calculated in every Angular component.
 */
public class StockPriceDto {

    private String ticker;
    private String companyName;
    private BigDecimal currentPrice;
    private BigDecimal openPrice;
    private BigDecimal highPrice;
    private BigDecimal lowPrice;
    private BigDecimal changePercent;
    private Long volume;
    private String priceDirection; // "UP", "DOWN", "FLAT"
    private LocalDateTime recordedAt;

    public StockPriceDto() {}

    public StockPriceDto(String ticker, String companyName,
                          BigDecimal currentPrice, BigDecimal openPrice,
                          BigDecimal highPrice, BigDecimal lowPrice,
                          BigDecimal changePercent, Long volume,
                          LocalDateTime recordedAt) {
        this.ticker = ticker;
        this.companyName = companyName;
        this.currentPrice = currentPrice;
        this.openPrice = openPrice;
        this.highPrice = highPrice;
        this.lowPrice = lowPrice;
        this.changePercent = changePercent;
        this.volume = volume;
        this.recordedAt = recordedAt;
        this.priceDirection = changePercent != null ?
            (changePercent.compareTo(BigDecimal.ZERO) > 0 ? "UP" :
             changePercent.compareTo(BigDecimal.ZERO) < 0 ? "DOWN" : "FLAT")
            : "FLAT";
    }

    public String getTicker() { return ticker; }
    public String getCompanyName() { return companyName; }
    public BigDecimal getCurrentPrice() { return currentPrice; }
    public BigDecimal getOpenPrice() { return openPrice; }
    public BigDecimal getHighPrice() { return highPrice; }
    public BigDecimal getLowPrice() { return lowPrice; }
    public BigDecimal getChangePercent() { return changePercent; }
    public Long getVolume() { return volume; }
    public String getPriceDirection() { return priceDirection; }
    public LocalDateTime getRecordedAt() { return recordedAt; }
}
