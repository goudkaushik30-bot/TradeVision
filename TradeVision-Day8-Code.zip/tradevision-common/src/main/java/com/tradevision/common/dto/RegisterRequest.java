package com.tradevision.common.dto;

/**
 * RegisterRequest DTO — Day 2
 *
 * WHY DTOs (Data Transfer Objects)?
 * We NEVER expose our Entity (database object) directly in the API.
 * Reason: The User entity has sensitive fields (password hash, internal IDs).
 * DTOs are clean objects with only the data the client needs to send/receive.
 * This is the DTO layer pattern — a standard in enterprise Java development.
 */
public class RegisterRequest {
    private String username;
    private String email;
    private String password;

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
}
