package com.tradevision.common.event;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * PriceAlertEvent — Day 6 TradeVision
 *
 * WHAT IS THIS?
 * This is the Kafka MESSAGE — the data that travels through
 * the event streaming pipeline from producer to consumer.
 *
 * WHY A DEDICATED EVENT CLASS?
 * In event-driven architecture, events are first-class citizens.
 * They represent something that HAPPENED in the system.
 * PriceAlertEvent = "A stock price crossed a threshold"
 * This event is serialised to JSON, published to Kafka topic,
 * consumed by Alert Service, and triggers a notification.
 *
 * WHY NOT JUST USE THE ENTITY DIRECTLY?
 * Events should be immutable, lightweight, self-contained.
 * Sending the full StockPrice entity through Kafka would
 * couple the consumer to the producer's data model.
 * Events decouple services — producer doesn't know who consumes.
 *
 * KAFKA TOPIC: "price-alerts"
 * This event flows: StockService → Kafka → AlertService → User
 */
public class PriceAlertEvent {

    private String ticker;
    private String companyName;
    private BigDecimal triggeredPrice;
    private BigDecimal thresholdPrice;
    private String alertType;      // "ABOVE" or "BELOW"
    private Long userId;
    private Long alertId;
    private LocalDateTime triggeredAt;

    public PriceAlertEvent() {}

    public PriceAlertEvent(String ticker, String companyName,
                            BigDecimal triggeredPrice, BigDecimal thresholdPrice,
                            String alertType, Long userId, Long alertId) {
        this.ticker = ticker;
        this.companyName = companyName;
        this.triggeredPrice = triggeredPrice;
        this.thresholdPrice = thresholdPrice;
        this.alertType = alertType;
        this.userId = userId;
        this.alertId = alertId;
        this.triggeredAt = LocalDateTime.now();
    }

    public String getTicker() { return ticker; }
    public void setTicker(String ticker) { this.ticker = ticker; }
    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }
    public BigDecimal getTriggeredPrice() { return triggeredPrice; }
    public void setTriggeredPrice(BigDecimal triggeredPrice) { this.triggeredPrice = triggeredPrice; }
    public BigDecimal getThresholdPrice() { return thresholdPrice; }
    public void setThresholdPrice(BigDecimal thresholdPrice) { this.thresholdPrice = thresholdPrice; }
    public String getAlertType() { return alertType; }
    public void setAlertType(String alertType) { this.alertType = alertType; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public Long getAlertId() { return alertId; }
    public void setAlertId(Long alertId) { this.alertId = alertId; }
    public LocalDateTime getTriggeredAt() { return triggeredAt; }
    public void setTriggeredAt(LocalDateTime triggeredAt) { this.triggeredAt = triggeredAt; }
}
