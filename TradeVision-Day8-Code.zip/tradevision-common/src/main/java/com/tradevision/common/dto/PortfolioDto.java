package com.tradevision.common.dto;

import java.math.BigDecimal;
import java.util.List;

/**
 * PortfolioDto — Day 5 TradeVision
 * Complete portfolio summary sent to Angular frontend.
 * One API call returns everything the dashboard needs.
 */
public class PortfolioDto {

    private BigDecimal totalValue;
    private BigDecimal totalInvested;
    private BigDecimal totalUnrealisedPnl;
    private BigDecimal totalUnrealisedPnlPercent;
    private List<HoldingDto> holdings;

    public PortfolioDto(BigDecimal totalValue, BigDecimal totalInvested,
                         BigDecimal totalUnrealisedPnl,
                         BigDecimal totalUnrealisedPnlPercent,
                         List<HoldingDto> holdings) {
        this.totalValue = totalValue;
        this.totalInvested = totalInvested;
        this.totalUnrealisedPnl = totalUnrealisedPnl;
        this.totalUnrealisedPnlPercent = totalUnrealisedPnlPercent;
        this.holdings = holdings;
    }

    public BigDecimal getTotalValue() { return totalValue; }
    public BigDecimal getTotalInvested() { return totalInvested; }
    public BigDecimal getTotalUnrealisedPnl() { return totalUnrealisedPnl; }
    public BigDecimal getTotalUnrealisedPnlPercent() { return totalUnrealisedPnlPercent; }
    public List<HoldingDto> getHoldings() { return holdings; }

    public static class HoldingDto {
        private String ticker;
        private String companyName;
        private BigDecimal quantity;
        private BigDecimal avgCostBasis;
        private BigDecimal currentPrice;
        private BigDecimal currentValue;
        private BigDecimal unrealisedPnl;
        private BigDecimal unrealisedPnlPercent;
        private String direction;

        public HoldingDto(String ticker, String companyName,
                           BigDecimal quantity, BigDecimal avgCostBasis,
                           BigDecimal currentPrice, BigDecimal currentValue,
                           BigDecimal unrealisedPnl, BigDecimal unrealisedPnlPercent) {
            this.ticker = ticker;
            this.companyName = companyName;
            this.quantity = quantity;
            this.avgCostBasis = avgCostBasis;
            this.currentPrice = currentPrice;
            this.currentValue = currentValue;
            this.unrealisedPnl = unrealisedPnl;
            this.unrealisedPnlPercent = unrealisedPnlPercent;
            this.direction = unrealisedPnl.compareTo(java.math.BigDecimal.ZERO) >= 0
                ? "UP" : "DOWN";
        }

        public String getTicker() { return ticker; }
        public String getCompanyName() { return companyName; }
        public BigDecimal getQuantity() { return quantity; }
        public BigDecimal getAvgCostBasis() { return avgCostBasis; }
        public BigDecimal getCurrentPrice() { return currentPrice; }
        public BigDecimal getCurrentValue() { return currentValue; }
        public BigDecimal getUnrealisedPnl() { return unrealisedPnl; }
        public BigDecimal getUnrealisedPnlPercent() { return unrealisedPnlPercent; }
        public String getDirection() { return direction; }
    }
}
