package com.tradevision.common.dto.kafka;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * PriceAlertEvent — Day 6 TradeVision
 *
 * WHAT IS THIS?
 * This is the message object that flows through Kafka.
 * When a stock price crosses a threshold, a PriceAlertEvent
 * is published to the Kafka topic "price-alerts".
 * The alert consumer picks it up and notifies the user.
 *
 * WHY A SEPARATE EVENT OBJECT?
 * Kafka works with serialised messages (JSON in our case).
 * This DTO represents the contract between producer and consumer.
 * Producer and consumer can live in different microservices —
 * they only share this event schema, nothing else.
 * This is the foundation of event-driven architecture.
 *
 * WHY EVENT-DRIVEN vs DIRECT API CALL?
 * Direct: StockService calls AlertService directly.
 *   → Tight coupling. If AlertService is down, StockService fails.
 *   → Synchronous — StockService waits for AlertService response.
 *
 * Event-driven via Kafka:
 *   → StockService publishes event and moves on immediately.
 *   → AlertService processes when ready — independently.
 *   → If AlertService restarts, Kafka replays missed events.
 *   → This is how USAA's fraud detection system works —
 *     transaction events flow through Kafka, fraud rules
 *     consume independently, no service couples to another.
 */
public class PriceAlertEvent {

    private String eventId;
    private String ticker;
    private String companyName;
    private BigDecimal triggeredPrice;
    private BigDecimal thresholdPrice;
    private String alertType;    // "ABOVE" or "BELOW"
    private Long userId;
    private String alertMessage;
    private LocalDateTime occurredAt;

    public PriceAlertEvent() {}

    public PriceAlertEvent(String eventId, String ticker, String companyName,
                            BigDecimal triggeredPrice, BigDecimal thresholdPrice,
                            String alertType, Long userId, String alertMessage) {
        this.eventId = eventId;
        this.ticker = ticker;
        this.companyName = companyName;
        this.triggeredPrice = triggeredPrice;
        this.thresholdPrice = thresholdPrice;
        this.alertType = alertType;
        this.userId = userId;
        this.alertMessage = alertMessage;
        this.occurredAt = LocalDateTime.now();
    }

    public String getEventId() { return eventId; }
    public void setEventId(String eventId) { this.eventId = eventId; }
    public String getTicker() { return ticker; }
    public void setTicker(String ticker) { this.ticker = ticker; }
    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }
    public BigDecimal getTriggeredPrice() { return triggeredPrice; }
    public void setTriggeredPrice(BigDecimal triggeredPrice) { this.triggeredPrice = triggeredPrice; }
    public BigDecimal getThresholdPrice() { return thresholdPrice; }
    public void setThresholdPrice(BigDecimal thresholdPrice) { this.thresholdPrice = thresholdPrice; }
    public String getAlertType() { return alertType; }
    public void setAlertType(String alertType) { this.alertType = alertType; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getAlertMessage() { return alertMessage; }
    public void setAlertMessage(String alertMessage) { this.alertMessage = alertMessage; }
    public LocalDateTime getOccurredAt() { return occurredAt; }
    public void setOccurredAt(LocalDateTime occurredAt) { this.occurredAt = occurredAt; }
}
