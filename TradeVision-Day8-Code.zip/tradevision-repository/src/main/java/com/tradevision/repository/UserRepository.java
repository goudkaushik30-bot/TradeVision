package com.tradevision.repository;

import com.tradevision.repository.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**
 * UserRepository — Day 2 TradeVision
 *
 * WHY Spring Data JPA Repository?
 * By extending JpaRepository, we get 20+ database operations for FREE:
 * - save(), findById(), findAll(), delete(), count() etc.
 * No SQL needed. Spring generates the queries automatically.
 *
 * WHY Optional<User>?
 * Java 8 Optional prevents NullPointerException.
 * Instead of returning null (which crashes), it returns Optional.empty()
 * which we can handle gracefully. Critical in financial apps.
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByUsername(String username);

    Optional<User> findByEmail(String email);

    Boolean existsByUsername(String username);

    Boolean existsByEmail(String email);
}
