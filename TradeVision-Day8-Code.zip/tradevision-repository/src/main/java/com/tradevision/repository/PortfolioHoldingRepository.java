package com.tradevision.repository;

import com.tradevision.repository.entity.PortfolioHolding;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Repository
public interface PortfolioHoldingRepository extends JpaRepository<PortfolioHolding, Long> {

    List<PortfolioHolding> findByUserId(Long userId);

    Optional<PortfolioHolding> findByUserIdAndTicker(Long userId, String ticker);

    // Total portfolio value for a user
    @Query("SELECT COALESCE(SUM(h.currentValue), 0) FROM PortfolioHolding h WHERE h.userId = :userId")
    BigDecimal getTotalPortfolioValue(@Param("userId") Long userId);

    // Total unrealised P&L
    @Query("SELECT COALESCE(SUM(h.unrealisedPnl), 0) FROM PortfolioHolding h WHERE h.userId = :userId")
    BigDecimal getTotalUnrealisedPnl(@Param("userId") Long userId);
}
