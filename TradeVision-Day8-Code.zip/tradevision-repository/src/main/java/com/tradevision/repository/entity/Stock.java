package com.tradevision.repository.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "stocks")
public class Stock {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false, length = 10)
    private String ticker;

    @Column(nullable = false)
    private String companyName;

    @Column(precision = 15, scale = 4)
    private BigDecimal currentPrice;

    @Column(precision = 5, scale = 2)
    private BigDecimal changePercent;

    private LocalDateTime lastUpdated;

    public Long getId() { return id; }
    public String getTicker() { return ticker; }
    public void setTicker(String ticker) { this.ticker = ticker; }
    public String getCompanyName() { return companyName; }
    public void setCompanyName(String name) { this.companyName = name; }
    public BigDecimal getCurrentPrice() { return currentPrice; }
    public void setCurrentPrice(BigDecimal price) { this.currentPrice = price; }
    public BigDecimal getChangePercent() { return changePercent; }
    public void setChangePercent(BigDecimal change) { this.changePercent = change; }
    public LocalDateTime getLastUpdated() { return lastUpdated; }
    public void setLastUpdated(LocalDateTime time) { this.lastUpdated = time; }
}
