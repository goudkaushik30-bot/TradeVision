package com.tradevision.repository.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * User Entity — Day 2 TradeVision
 *
 * WHY JPA/Hibernate?
 * Instead of writing raw SQL, JPA maps Java objects directly to database tables.
 * Hibernate (the JPA implementation) handles all CRUD operations automatically.
 * This saves hundreds of lines of boilerplate SQL code.
 *
 * WHY PostgreSQL?
 * Unlike MySQL, PostgreSQL supports advanced data types, better concurrency,
 * and ACID compliance — critical for financial transaction data integrity.
 */
@Entity
@Table(name = "users",
       uniqueConstraints = {
           @UniqueConstraint(columnNames = "email"),
           @UniqueConstraint(columnNames = "username")
       })
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 50)
    private String username;

    @Column(nullable = false, length = 100)
    private String email;

    /**
     * WHY we store hashed password, not plain text?
     * BCrypt hashing (Spring Security) makes passwords irreversible.
     * Even if the database is breached, passwords cannot be recovered.
     * This is a non-negotiable security standard in fintech.
     */
    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String role = "ROLE_USER";  // ROLE_USER or ROLE_ADMIN

    @Column(nullable = false)
    private Boolean enabled = true;

    @Column(updatable = false)
    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public Boolean getEnabled() { return enabled; }
    public void setEnabled(Boolean enabled) { this.enabled = enabled; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
}
