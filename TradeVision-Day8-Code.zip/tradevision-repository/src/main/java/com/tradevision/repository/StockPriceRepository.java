package com.tradevision.repository;

import com.tradevision.repository.entity.StockPrice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * StockPriceRepository — Day 4 TradeVision
 *
 * WHY custom @Query methods?
 * Spring Data JPA auto-generates simple queries from method names.
 * But for complex queries (latest price per ticker, time-range queries),
 * we write JPQL (Java Persistence Query Language) — it's SQL but
 * object-oriented, works with our entity classes not raw table names.
 *
 * WHY findTopByTickerOrderByRecordedAtDesc?
 * This fetches the single most recent price for a ticker.
 * Spring Data parses the method name: findTop(1) + ByTicker + OrderBy + Desc
 * No SQL needed. Spring generates the optimised query automatically.
 *
 * WHY store historical data at all?
 * Every price alert, P&L calculation, chart rendering needs history.
 * At Fidelity we stored tick-level data going back years.
 * TradeVision follows the same principle — store everything.
 */
@Repository
public interface StockPriceRepository extends JpaRepository<StockPrice, Long> {

    // Latest price for a specific ticker
    Optional<StockPrice> findTopByTickerOrderByRecordedAtDesc(String ticker);

    // All historical prices for a ticker (for charts)
    List<StockPrice> findByTickerOrderByRecordedAtAsc(String ticker);

    // Price history within a date range
    @Query("SELECT s FROM StockPrice s WHERE s.ticker = :ticker " +
           "AND s.recordedAt BETWEEN :from AND :to " +
           "ORDER BY s.recordedAt ASC")
    List<StockPrice> findPriceHistory(
        @Param("ticker") String ticker,
        @Param("from") LocalDateTime from,
        @Param("to") LocalDateTime to
    );

    // Get latest price for all tracked tickers (dashboard view)
    @Query("SELECT s FROM StockPrice s WHERE s.recordedAt = " +
           "(SELECT MAX(s2.recordedAt) FROM StockPrice s2 WHERE s2.ticker = s.ticker)")
    List<StockPrice> findLatestPricesForAllTickers();
}
