package com.tradevision.repository.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * PortfolioHolding Entity — Day 5 TradeVision
 *
 * WHAT IS A HOLDING?
 * A holding = one stock a user owns.
 * If user buys 10 shares of AAPL at $189.50, that's one holding.
 * Later buys 5 more at $191.00 — we average the cost basis.
 *
 * WHY average cost basis?
 * In real trading platforms (Fidelity, USAA), when you buy the same
 * stock multiple times at different prices, you track the AVERAGE
 * price you paid. This is the cost basis for P&L calculation.
 *
 * WHY store unrealisedPnl in the DB vs computing on the fly?
 * Computed on the fly = correct but slow for large portfolios.
 * Stored in DB = fast reads, updated on each price tick.
 * TradeVision updates unrealisedPnl every time prices refresh.
 * Same approach used in institutional portfolio systems.
 */
@Entity
@Table(name = "portfolio_holdings",
    uniqueConstraints = @UniqueConstraint(columnNames = {"user_id", "ticker"}))
public class PortfolioHolding {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(nullable = false, length = 10)
    private String ticker;

    @Column(nullable = false)
    private String companyName;

    // Total shares owned
    @Column(nullable = false, precision = 15, scale = 4)
    private BigDecimal quantity;

    // Average price paid across all buy orders
    @Column(nullable = false, precision = 15, scale = 4)
    private BigDecimal avgCostBasis;

    // Current market value = quantity * currentPrice
    @Column(precision = 15, scale = 4)
    private BigDecimal currentValue;

    // Unrealised P&L = currentValue - (quantity * avgCostBasis)
    @Column(precision = 15, scale = 4)
    private BigDecimal unrealisedPnl;

    // Unrealised P&L as percentage
    @Column(precision = 10, scale = 2)
    private BigDecimal unrealisedPnlPercent;

    @Column(updatable = false)
    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getTicker() { return ticker; }
    public void setTicker(String ticker) { this.ticker = ticker; }
    public String getCompanyName() { return companyName; }
    public void setCompanyName(String n) { this.companyName = n; }
    public BigDecimal getQuantity() { return quantity; }
    public void setQuantity(BigDecimal quantity) { this.quantity = quantity; }
    public BigDecimal getAvgCostBasis() { return avgCostBasis; }
    public void setAvgCostBasis(BigDecimal avgCostBasis) { this.avgCostBasis = avgCostBasis; }
    public BigDecimal getCurrentValue() { return currentValue; }
    public void setCurrentValue(BigDecimal currentValue) { this.currentValue = currentValue; }
    public BigDecimal getUnrealisedPnl() { return unrealisedPnl; }
    public void setUnrealisedPnl(BigDecimal pnl) { this.unrealisedPnl = pnl; }
    public BigDecimal getUnrealisedPnlPercent() { return unrealisedPnlPercent; }
    public void setUnrealisedPnlPercent(BigDecimal pct) { this.unrealisedPnlPercent = pct; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
}
