package com.tradevision.repository.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * PriceAlert Entity — Day 6
 *
 * WHY persist alerts to DB?
 * Users need to see their alert history — what triggered, when, at what price.
 * Also: if the app restarts, we reload active alerts from DB.
 * Kafka events are ephemeral — DB is the source of truth.
 *
 * STATUS LIFECYCLE:
 * ACTIVE   → alert is set, waiting to trigger
 * TRIGGERED → price crossed threshold, Kafka event published
 * CANCELLED → user manually cancelled
 */
@Entity
@Table(name = "price_alerts")
public class PriceAlert {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long userId;

    @Column(nullable = false, length = 10)
    private String ticker;

    @Column(nullable = false)
    private String companyName;

    @Column(nullable = false, precision = 15, scale = 4)
    private BigDecimal thresholdPrice;

    @Column(nullable = false, length = 10)
    private String alertType;  // ABOVE / BELOW

    @Column(nullable = false, length = 20)
    private String status = "ACTIVE";

    private BigDecimal triggeredAtPrice;
    private LocalDateTime triggeredAt;

    @Column(updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() { createdAt = LocalDateTime.now(); }

    public Long getId() { return id; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getTicker() { return ticker; }
    public void setTicker(String ticker) { this.ticker = ticker; }
    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }
    public BigDecimal getThresholdPrice() { return thresholdPrice; }
    public void setThresholdPrice(BigDecimal thresholdPrice) { this.thresholdPrice = thresholdPrice; }
    public String getAlertType() { return alertType; }
    public void setAlertType(String alertType) { this.alertType = alertType; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public BigDecimal getTriggeredAtPrice() { return triggeredAtPrice; }
    public void setTriggeredAtPrice(BigDecimal triggeredAtPrice) { this.triggeredAtPrice = triggeredAtPrice; }
    public LocalDateTime getTriggeredAt() { return triggeredAt; }
    public void setTriggeredAt(LocalDateTime triggeredAt) { this.triggeredAt = triggeredAt; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
