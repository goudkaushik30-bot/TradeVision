package com.tradevision.repository.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * StockPrice Entity — Day 4 TradeVision
 *
 * WHY A SEPARATE StockPrice entity?
 * We store EVERY price snapshot, not just the latest.
 * This gives us historical data for charts, analytics, P&L calculations.
 * Same approach used at Fidelity, USAA — you never throw away price history.
 *
 * WHY BigDecimal for price, NOT double or float?
 * This is critical in financial software.
 * double: 0.1 + 0.2 = 0.30000000000000004 (floating point error)
 * BigDecimal: 0.1 + 0.2 = 0.3 (exact)
 * In a trading platform, even a fraction of a cent error
 * multiplied across millions of transactions = massive financial discrepancy.
 * BigDecimal is non-negotiable in fintech.
 *
 * WHY scale(4) for price?
 * Stock prices go to 4 decimal places (e.g. AAPL: $189.4523)
 * scale(2) for changePercent is enough for percentage display.
 */
@Entity
@Table(name = "stock_prices", indexes = {
    @Index(name = "idx_ticker", columnList = "ticker"),
    @Index(name = "idx_recorded_at", columnList = "recordedAt")
})
public class StockPrice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 10)
    private String ticker;

    @Column(nullable = false)
    private String companyName;

    @Column(nullable = false, precision = 15, scale = 4)
    private BigDecimal currentPrice;

    @Column(precision = 15, scale = 4)
    private BigDecimal openPrice;

    @Column(precision = 15, scale = 4)
    private BigDecimal highPrice;

    @Column(precision = 15, scale = 4)
    private BigDecimal lowPrice;

    @Column(precision = 15, scale = 4)
    private BigDecimal previousClose;

    @Column(precision = 10, scale = 2)
    private BigDecimal changePercent;

    @Column(nullable = false)
    private Long volume;

    @Column(nullable = false)
    private LocalDateTime recordedAt;

    @PrePersist
    protected void onCreate() {
        recordedAt = LocalDateTime.now();
    }

    // Getters & Setters
    public Long getId() { return id; }
    public String getTicker() { return ticker; }
    public void setTicker(String ticker) { this.ticker = ticker; }
    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }
    public BigDecimal getCurrentPrice() { return currentPrice; }
    public void setCurrentPrice(BigDecimal currentPrice) { this.currentPrice = currentPrice; }
    public BigDecimal getOpenPrice() { return openPrice; }
    public void setOpenPrice(BigDecimal openPrice) { this.openPrice = openPrice; }
    public BigDecimal getHighPrice() { return highPrice; }
    public void setHighPrice(BigDecimal highPrice) { this.highPrice = highPrice; }
    public BigDecimal getLowPrice() { return lowPrice; }
    public void setLowPrice(BigDecimal lowPrice) { this.lowPrice = lowPrice; }
    public BigDecimal getPreviousClose() { return previousClose; }
    public void setPreviousClose(BigDecimal previousClose) { this.previousClose = previousClose; }
    public BigDecimal getChangePercent() { return changePercent; }
    public void setChangePercent(BigDecimal changePercent) { this.changePercent = changePercent; }
    public Long getVolume() { return volume; }
    public void setVolume(Long volume) { this.volume = volume; }
    public LocalDateTime getRecordedAt() { return recordedAt; }
}
