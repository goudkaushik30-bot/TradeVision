package com.tradevision.api.config;

import com.tradevision.api.security.JwtAuthFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * SecurityConfig — Day 3 TradeVision
 *
 * WHY @EnableWebSecurity?
 * Tells Spring Boot to use OUR security config instead of the default.
 * Without this, Spring auto-configures basic auth (a login popup).
 * We need JWT-based security, so we take full control here.
 *
 * WHY @EnableMethodSecurity?
 * Enables @PreAuthorize annotations on individual methods.
 * Example: @PreAuthorize("hasRole('ADMIN')") on admin-only endpoints.
 * Fine-grained security — standard in financial applications.
 *
 * SESSION POLICY — STATELESS:
 * This is the most important line in this config.
 * STATELESS means Spring Security NEVER creates an HTTP session.
 * Every request must carry its own JWT. No cookies, no sessions.
 * This makes TradeVision horizontally scalable — any server instance
 * can handle any request because there's no shared session state.
 *
 * PUBLIC vs PROTECTED ROUTES:
 * /api/v1/auth/** → public (register, login — no token needed)
 * /api/v1/**      → protected (everything else needs valid JWT)
 *
 * WHY CSRF disabled?
 * CSRF attacks work by exploiting session cookies.
 * We use JWT in headers — not cookies — so CSRF doesn't apply.
 * Disabling it removes unnecessary overhead.
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Autowired
    private JwtAuthFilter jwtAuthFilter;

    @Autowired
    private UserDetailsService userDetailsService;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            // Disable CSRF — we use JWT, not cookies
            .csrf(csrf -> csrf.disable())

            // Define which routes are public vs protected
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/v1/auth/**").permitAll()
                .requestMatchers("/actuator/health").permitAll()
                .anyRequest().authenticated()
            )

            // STATELESS — no sessions, ever
            .sessionManagement(session -> session
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            )

            // Plug in our JWT filter BEFORE Spring's default auth filter
            .addFilterBefore(jwtAuthFilter,
                UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        // BCrypt with strength 12 — 2^12 = 4096 hashing rounds
        // Strong enough to resist brute force, fast enough for UX
        return new BCryptPasswordEncoder(12);
    }

    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService);
        provider.setPasswordEncoder(passwordEncoder());
        return provider;
    }
}
