package com.tradevision.api.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import java.security.Key;
import java.util.Date;

/**
 * JwtUtils — Day 2 TradeVision
 *
 * WHAT IS JWT?
 * JSON Web Token = a digitally signed string that proves who you are.
 * Format: header.payload.signature
 * Example: eyJhbGci....eyJ1c2VyIj....HmacSHA256
 *
 * WHY JWT instead of sessions?
 * Sessions store user state on the SERVER (memory/database).
 * JWT stores user state on the CLIENT (the token itself).
 *
 * In microservices architecture (like TradeVision), we have 5 services.
 * With sessions, each service needs to check a shared session store.
 * With JWT, each service independently verifies the token — NO network call needed.
 * This makes our system faster, stateless, and horizontally scalable.
 *
 * WHY HMAC-SHA256 signing?
 * The token is signed with a secret key. Any tampering with the payload
 * invalidates the signature. So hackers cannot modify token contents.
 *
 * EXPIRY: 24 hours (86400000ms)
 * Best practice: short-lived tokens + refresh token pattern
 */
@Component
public class JwtUtils {

    @Value("${jwt.secret}")
    private String jwtSecret;

    @Value("${jwt.expiration}")
    private int jwtExpiration;

    private Key getSigningKey() {
        return Keys.hmacShaKeyFor(jwtSecret.getBytes());
    }

    public String generateToken(String username) {
        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + jwtExpiration))
                .signWith(getSigningKey(), SignatureAlgorithm.HS256)
                .compact();
    }

    public String getUsernameFromToken(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getSigningKey())
                .build()
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
    }

    public boolean validateToken(String token) {
        try {
            Jwts.parserBuilder()
                .setSigningKey(getSigningKey())
                .build()
                .parseClaimsJws(token);
            return true;
        } catch (JwtException | IllegalArgumentException e) {
            return false;
        }
    }
}
