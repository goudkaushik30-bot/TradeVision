package com.tradevision.api.controller;

import com.tradevision.api.security.JwtUtils;
import com.tradevision.common.dto.*;
import com.tradevision.repository.UserRepository;
import com.tradevision.repository.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

/**
 * AuthController — Day 2 TradeVision
 *
 * WHY Spring Boot REST Controller?
 * @RestController = @Controller + @ResponseBody
 * Every method automatically serialises return values to JSON.
 * No manual JSON conversion needed — Jackson library does it for us.
 *
 * WHY /api/v1/ prefix?
 * API versioning best practice. When we release breaking changes,
 * we create /api/v2/ without breaking existing clients.
 * Used by every major fintech API (Stripe, Plaid, Fidelity).
 *
 * TWO ENDPOINTS TODAY:
 * POST /api/v1/auth/register — create new user account
 * POST /api/v1/auth/login    — authenticate and return JWT
 */
@RestController
@RequestMapping("/api/v1/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtils jwtUtils;

    /**
     * REGISTER endpoint
     * WHY BCrypt password encoding?
     * BCrypt adds a random "salt" to each password before hashing.
     * This means even if two users have the same password, their hashes differ.
     * Prevents rainbow table attacks — a standard fintech security requirement.
     */
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest request) {

        if (userRepository.existsByUsername(request.getUsername())) {
            return ResponseEntity.badRequest()
                .body(new AuthResponse(null, null, "Username already taken"));
        }

        if (userRepository.existsByEmail(request.getEmail())) {
            return ResponseEntity.badRequest()
                .body(new AuthResponse(null, null, "Email already registered"));
        }

        User user = new User();
        user.setUsername(request.getUsername());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));

        userRepository.save(user);

        String token = jwtUtils.generateToken(user.getUsername());
        return ResponseEntity.ok(new AuthResponse(token, user.getUsername(), "Registration successful"));
    }

    /**
     * LOGIN endpoint
     * WHY AuthenticationManager?
     * Spring Security's AuthenticationManager handles the full auth flow:
     * 1. Loads user from DB by username
     * 2. Compares BCrypt hash of provided password with stored hash
     * 3. Throws exception if mismatch (we return 401)
     * 4. Returns authenticated user if match (we generate JWT)
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        try {
            Authentication auth = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                    request.getUsername(),
                    request.getPassword()
                )
            );

            String token = jwtUtils.generateToken(request.getUsername());
            return ResponseEntity.ok(new AuthResponse(token, request.getUsername(), "Login successful"));

        } catch (BadCredentialsException e) {
            return ResponseEntity.status(401)
                .body(new AuthResponse(null, null, "Invalid username or password"));
        }
    }
}
