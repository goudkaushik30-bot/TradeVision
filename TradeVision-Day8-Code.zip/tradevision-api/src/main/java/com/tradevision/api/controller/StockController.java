package com.tradevision.api.controller;

import com.tradevision.common.dto.StockPriceDto;
import com.tradevision.service.impl.StockServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * StockController — Day 4 TradeVision
 *
 * WHY @PreAuthorize("isAuthenticated()")?
 * All stock endpoints require a valid JWT.
 * This annotation checks authentication at the METHOD level —
 * a second layer of protection beyond SecurityConfig.
 * Defence in depth: two independent checks means one misconfiguration
 * doesn't expose data. Standard practice in financial APIs.
 *
 * ENDPOINTS TODAY:
 * GET /api/v1/stocks           → all latest prices (dashboard)
 * GET /api/v1/stocks/{ticker}  → single stock detail
 * GET /api/v1/stocks/{ticker}/history → price history for charts
 */
@RestController
@RequestMapping("/api/v1/stocks")
@CrossOrigin(origins = "*")
public class StockController {

    @Autowired
    private StockServiceImpl stockService;

    @GetMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<List<StockPriceDto>> getAllStocks() {
        return ResponseEntity.ok(stockService.getAllLatestPrices());
    }

    @GetMapping("/{ticker}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<StockPriceDto> getStock(
            @PathVariable String ticker) {
        return ResponseEntity.ok(
            stockService.getLatestPrice(ticker.toUpperCase())
        );
    }
}
