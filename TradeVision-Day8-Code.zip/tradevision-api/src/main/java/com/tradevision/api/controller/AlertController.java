package com.tradevision.api.controller;

import com.tradevision.repository.PriceAlertRepository;
import com.tradevision.repository.entity.PriceAlert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

/**
 * AlertController — Day 6 TradeVision
 *
 * ENDPOINTS:
 * POST /api/v1/alerts         → create a new price alert
 * GET  /api/v1/alerts/{userId} → get all alerts for user
 * DELETE /api/v1/alerts/{id}  → cancel an alert
 */
@RestController
@RequestMapping("/api/v1/alerts")
@CrossOrigin(origins = "*")
public class AlertController {

    @Autowired
    private PriceAlertRepository alertRepository;

    @PostMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<PriceAlert> createAlert(@RequestBody PriceAlert alert) {
        alert.setStatus("ACTIVE");
        return ResponseEntity.ok(alertRepository.save(alert));
    }

    @GetMapping("/{userId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<List<PriceAlert>> getUserAlerts(@PathVariable Long userId) {
        return ResponseEntity.ok(
            alertRepository.findByUserIdOrderByCreatedAtDesc(userId)
        );
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Map<String,String>> cancelAlert(@PathVariable Long id) {
        alertRepository.findById(id).ifPresent(a -> {
            a.setStatus("CANCELLED");
            alertRepository.save(a);
        });
        return ResponseEntity.ok(Map.of("message", "Alert cancelled"));
    }
}
