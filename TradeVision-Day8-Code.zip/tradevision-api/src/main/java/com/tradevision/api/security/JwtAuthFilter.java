package com.tradevision.api.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;

/**
 * JwtAuthFilter — Day 3 TradeVision
 *
 * WHAT IS THIS?
 * Every HTTP request to TradeVision passes through this filter FIRST.
 * It's a gatekeeper — intercepts requests, reads the JWT token,
 * validates it, and tells Spring Security who the user is.
 *
 * WHY OncePerRequestFilter?
 * Spring can sometimes call filters multiple times per request.
 * OncePerRequestFilter guarantees this runs EXACTLY once per request.
 * Critical for auth — you don't want the same token validated twice
 * and creating race conditions in concurrent financial transactions.
 *
 * THE FILTER CHAIN CONCEPT:
 * Think of it as a pipeline:
 * Request → JwtAuthFilter → SecurityConfig → Controller → Response
 *
 * If JWT is invalid → filter stops the request here → 401 returned
 * If JWT is valid   → filter sets authentication → request proceeds
 *
 * WHY Bearer token in Authorization header?
 * Industry standard (RFC 6750). Every major fintech API uses this.
 * "Authorization: Bearer eyJhbGci..."
 * Separates auth concern from request body — clean, stateless.
 */
@Component
public class JwtAuthFilter extends OncePerRequestFilter {

    @Autowired
    private JwtUtils jwtUtils;

    @Autowired
    private UserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain) throws ServletException, IOException {

        // Step 1: Extract Authorization header
        String authHeader = request.getHeader("Authorization");

        // Step 2: Check if it's a Bearer token
        // If no token → just continue (public endpoints are allowed)
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return;
        }

        // Step 3: Extract just the token (remove "Bearer " prefix)
        String token = authHeader.substring(7);

        // Step 4: Extract username from token
        String username = null;
        try {
            username = jwtUtils.getUsernameFromToken(token);
        } catch (Exception e) {
            // Invalid token structure — let Spring Security handle the 401
            filterChain.doFilter(request, response);
            return;
        }

        // Step 5: If username found AND no existing auth in context
        // (we don't want to override an already-authenticated session)
        if (username != null &&
            SecurityContextHolder.getContext().getAuthentication() == null) {

            // Step 6: Load full user details from DB
            UserDetails userDetails = userDetailsService.loadUserByUsername(username);

            // Step 7: Validate token against user details
            if (jwtUtils.validateToken(token)) {

                // Step 8: Create authentication object
                UsernamePasswordAuthenticationToken authToken =
                    new UsernamePasswordAuthenticationToken(
                        userDetails,
                        null,
                        userDetails.getAuthorities()
                    );

                authToken.setDetails(
                    new WebAuthenticationDetailsSource().buildDetails(request)
                );

                // Step 9: Set authentication in Spring Security context
                // After this line — the request is "authenticated"
                SecurityContextHolder.getContext().setAuthentication(authToken);
            }
        }

        // Step 10: Continue the filter chain
        filterChain.doFilter(request, response);
    }
}
