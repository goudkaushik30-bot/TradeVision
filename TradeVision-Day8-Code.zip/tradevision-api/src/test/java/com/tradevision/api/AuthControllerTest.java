package com.tradevision.api;

import com.tradevision.api.security.JwtUtils;
import com.tradevision.common.dto.LoginRequest;
import com.tradevision.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import com.fasterxml.jackson.databind.ObjectMapper;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * AuthControllerTest — Day 8 TradeVision
 *
 * WHY MockMvc for controller tests?
 * MockMvc lets us test HTTP endpoints without starting a real server.
 * We test the full request → response cycle including:
 * - HTTP method, URL, request body
 * - Response status code, JSON fields
 * - Spring Security filter behaviour
 *
 * WHY @SpringBootTest?
 * Loads the full application context — real beans, real config.
 * Slower than unit tests but catches integration issues.
 * @WebMvcTest is faster but only loads MVC layer.
 * We use @SpringBootTest here because auth needs the full security chain.
 *
 * WHY @DisplayName?
 * Test names that read like requirements:
 * "login with valid credentials returns JWT token"
 * Not "testLogin1". Makes test reports readable by non-developers.
 *
 * TEST COVERAGE STRATEGY:
 * Happy path → valid credentials → 200 + token
 * Sad path  → invalid password → 401
 * Edge case → missing username field → 400
 * Security  → protected endpoint without token → 401
 */
@SpringBootTest
@AutoConfigureMockMvc
class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtUtils jwtUtils;

    private String validToken;

    @BeforeEach
    void setUp() {
        validToken = jwtUtils.generateToken("test_user");
    }

    @Test
    @DisplayName("login with valid credentials returns JWT token")
    void loginWithValidCredentials_returnsToken() throws Exception {
        LoginRequest request = new LoginRequest();
        request.setUsername("test_user");
        request.setPassword("test_password");

        mockMvc.perform(post("/api/v1/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.token").exists())
            .andExpect(jsonPath("$.username").value("test_user"))
            .andExpect(jsonPath("$.message").value("Login successful"));
    }

    @Test
    @DisplayName("login with invalid password returns 401 unauthorized")
    void loginWithInvalidPassword_returns401() throws Exception {
        LoginRequest request = new LoginRequest();
        request.setUsername("test_user");
        request.setPassword("wrong_password");

        mockMvc.perform(post("/api/v1/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isUnauthorized())
            .andExpect(jsonPath("$.message").value("Invalid username or password"));
    }

    @Test
    @DisplayName("accessing protected endpoint without token returns 401")
    void accessProtectedEndpointWithoutToken_returns401() throws Exception {
        mockMvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders
                .get("/api/v1/stocks"))
            .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("accessing protected endpoint with valid token returns 200")
    void accessProtectedEndpointWithValidToken_returns200() throws Exception {
        mockMvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders
                .get("/api/v1/stocks")
                .header("Authorization", "Bearer " + validToken))
            .andExpect(status().isOk());
    }
}
