package com.tradevision.api.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/v1/stocks")
@CrossOrigin(origins = "*")
public class StockController {

    @GetMapping
    public ResponseEntity<List<Map<String, Object>>> getAllStocks() {
        List<Map<String, Object>> stocks = new ArrayList<>();
        stocks.add(createStock("AAPL", "Apple Inc.", 189.50, 0.82));
        stocks.add(createStock("GOOGL", "Alphabet Inc.", 141.80, -0.34));
        stocks.add(createStock("MSFT", "Microsoft Corp.", 378.90, 1.12));
        stocks.add(createStock("AMZN", "Amazon.com Inc.", 178.25, 0.56));
        stocks.add(createStock("TSLA", "Tesla Inc.", 248.50, -1.23));
        return ResponseEntity.ok(stocks);
    }

    @GetMapping("/{ticker}")
    public ResponseEntity<Map<String, Object>> getStock(@PathVariable String ticker) {
        return ResponseEntity.ok(createStock(ticker.toUpperCase(), ticker + " Corp.", 100.00, 0.5));
    }

    private Map<String, Object> createStock(String ticker, String name, double price, double change) {
        Map<String, Object> s = new LinkedHashMap<>();
        s.put("ticker", ticker);
        s.put("companyName", name);
        s.put("currentPrice", price);
        s.put("changePercent", change);
        s.put("lastUpdated", new Date().toString());
        return s;
    }
}
