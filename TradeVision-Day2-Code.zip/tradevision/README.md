# TradeVision 📈

> A production-grade Stock Trading & Portfolio Tracker — built in public, one day at a time.

[![Java](https://img.shields.io/badge/Java-17-orange)](https://openjdk.org/)
[![Spring Boot](https://img.shields.io/badge/Spring%20Boot-3.2-brightgreen)](https://spring.io/projects/spring-boot)
[![Angular](https://img.shields.io/badge/Angular-14-red)](https://angular.io/)
[![PostgreSQL](https://img.shields.io/badge/PostgreSQL-15-blue)](https://www.postgresql.org/)
[![Kafka](https://img.shields.io/badge/Apache%20Kafka-3.5-black)](https://kafka.apache.org/)

## 🚀 About

TradeVision is a full-stack stock trading and portfolio management platform built with enterprise-grade technologies. This project is being built and documented publicly over 30 days.

**Follow the journey:** [LinkedIn - Kaushik Katta](https://www.linkedin.com/in/kaushik-goud-katta-858363265)

## 🏗️ Architecture

```
tradevision/
├── tradevision-api/          # REST Controllers (Spring Boot)
├── tradevision-service/      # Business Logic Layer
├── tradevision-repository/   # Data Access Layer (JPA/Hibernate)
└── tradevision-common/       # Shared DTOs & Models
```

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Java 17, Spring Boot 3, Spring Security |
| Frontend | Angular 14, TypeScript, Bootstrap |
| Database | PostgreSQL 15, Redis (caching) |
| Messaging | Apache Kafka |
| DevOps | Docker, Kubernetes, Jenkins, AWS |

## 📋 30-Day Roadmap

- [x] Day 1: Project setup, architecture, Docker environment
- [ ] Day 2: User entity, JWT authentication API
- [ ] Day 3: Stock service, PostgreSQL integration
- [ ] Day 4: Portfolio service, CRUD operations
- [ ] Day 5: Kafka integration, real-time events
- [ ] ...and 25 more days!

## 🚦 Quick Start

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/tradevision.git
cd tradevision

# Start infrastructure
docker-compose up -d

# Run the app
./mvnw spring-boot:run -pl tradevision-api
```

## 📡 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/v1/stocks | Get all stocks |
| GET | /api/v1/stocks/{ticker} | Get stock by ticker |
| POST | /api/v1/auth/login | User login |
| GET | /api/v1/portfolio | Get user portfolio |

## 📸 Daily Progress

Follow daily updates on [LinkedIn](https://www.linkedin.com/in/kaushik-goud-katta-858363265)

---
Built with ❤️ by [Kaushik Katta](https://www.linkedin.com/in/kaushik-goud-katta-858363265) | Full Stack Java Developer
