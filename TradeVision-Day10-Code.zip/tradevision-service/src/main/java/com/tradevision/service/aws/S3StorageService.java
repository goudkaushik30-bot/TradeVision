package com.tradevision.service.aws;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.*;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * S3StorageService — Day 9 TradeVision
 *
 * WHAT IS S3?
 * Amazon S3 (Simple Storage Service) = infinitely scalable object storage.
 * Not a file system — objects (files + metadata) stored by key in buckets.
 * Key = "reports/2024/04/08/portfolio-report-user1.pdf"
 * No folders — just keys. The "/" is just naming convention.
 *
 * WHY S3 for TradeVision?
 * 1. Portfolio reports (PDF exports) — too large for DB, perfect for S3
 * 2. Price history CSV exports — users download their trade history
 * 3. Static Angular frontend assets — S3 + CloudFront = CDN delivery
 *
 * WHY NOT store files in PostgreSQL?
 * PostgreSQL BYTEA column works for small files.
 * But: every DB backup includes all files (bloat).
 * S3 is 99.999999999% durable, globally distributed, dirt cheap.
 * Standard enterprise pattern: DB for structured data, S3 for files.
 *
 * WHERE USED IN REAL SYSTEMS:
 * At USAA — transaction statement PDFs stored in S3.
 * At Fidelity — fund documents, tax forms, trade confirmations.
 * Every major fintech stores documents in S3 or equivalent.
 *
 * WHY AWS SDK v2 vs v1?
 * SDK v2: non-blocking async clients, immutable request builders,
 * better performance, active maintenance.
 * SDK v1: deprecated, synchronous only, legacy codebases.
 * Always use v2 for new projects.
 */
@Service
public class S3StorageService {

    private static final Logger log = LoggerFactory.getLogger(S3StorageService.class);

    @Value("${aws.s3.bucket-name}")
    private String bucketName;

    @Value("${aws.region}")
    private String region;

    private final S3Client s3Client;

    public S3StorageService(S3Client s3Client) {
        this.s3Client = s3Client;
    }

    /**
     * Upload portfolio report PDF for a user
     * Key pattern: reports/{year}/{month}/{day}/portfolio-user{userId}.pdf
     * WHY date-based partitioning?
     * Easy to find files by date, easy to set lifecycle policies
     * (auto-delete after 7 years for compliance).
     */
    public String uploadPortfolioReport(Long userId,
                                         InputStream pdfStream,
                                         long contentLength) {
        String datePrefix = LocalDate.now()
            .format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
        String key = String.format("reports/%s/portfolio-user%d.pdf",
            datePrefix, userId);

        try {
            PutObjectRequest request = PutObjectRequest.builder()
                .bucket(bucketName)
                .key(key)
                .contentType("application/pdf")
                .serverSideEncryption(ServerSideEncryption.AES256)
                // AES-256: encryption at rest — required for financial documents
                .metadata(java.util.Map.of(
                    "userId", userId.toString(),
                    "generatedAt", java.time.Instant.now().toString()
                ))
                .build();

            s3Client.putObject(request,
                RequestBody.fromInputStream(pdfStream, contentLength));

            log.info("Portfolio report uploaded: bucket={} key={}", bucketName, key);
            return key;

        } catch (S3Exception e) {
            log.error("S3 upload failed for user {}: {}", userId, e.getMessage());
            throw new RuntimeException("Failed to upload report to S3", e);
        }
    }

    /**
     * Generate pre-signed URL — user downloads directly from S3
     *
     * WHY pre-signed URL vs routing through our API?
     * Without pre-signed: client → our API → S3 → our API → client
     *   Our server handles all the bytes. Bandwidth cost. Latency.
     *
     * With pre-signed URL: client → S3 directly (URL expires in 15 min)
     *   Our server only generates the URL. S3 handles the download.
     *   Scales infinitely. No bandwidth cost on our EC2.
     *   This is how every serious file download system works.
     */
    public String generateDownloadUrl(String key, int expiryMinutes) {
        software.amazon.awssdk.services.s3.presigner.S3Presigner presigner =
            software.amazon.awssdk.services.s3.presigner.S3Presigner.builder()
                .region(software.amazon.awssdk.regions.Region.of(region))
                .build();

        software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest presignRequest =
            software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest.builder()
                .signatureDuration(java.time.Duration.ofMinutes(expiryMinutes))
                .getObjectRequest(GetObjectRequest.builder()
                    .bucket(bucketName)
                    .key(key)
                    .build())
                .build();

        String url = presigner.presignGetObject(presignRequest)
            .url().toString();

        presigner.close();
        log.info("Pre-signed URL generated for key={} expires={}min", key, expiryMinutes);
        return url;
    }
}
