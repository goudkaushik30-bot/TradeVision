#!/bin/bash
# ─────────────────────────────────────────────────────────────
# TradeVision AWS Deployment Script — Day 9
#
# WHAT THIS DOES:
# Deploys TradeVision to AWS EC2 using a blue-green strategy.
# Pulls latest Docker image, updates running container,
# validates health, and rolls back if anything fails.
#
# WHY BASH DEPLOYMENT SCRIPT vs Terraform?
# Bash: Simple, fast, no extra tooling, perfect for Day 9.
# Terraform: Infrastructure as Code — we add this Day 15.
# Progression matters in engineering — simple first,
# then add complexity when the simple version is working.
#
# WHY BLUE-GREEN DEPLOYMENT?
# Blue = currently running production (port 8080)
# Green = new version starting up (port 8081)
# Steps:
#   1. Start green container on port 8081
#   2. Health check green — passes
#   3. Switch load balancer to green
#   4. Stop blue container
# At no point is the user without a working service.
# Zero-downtime deployment. Used at Fidelity, USAA for all
# production releases during market hours.
# ─────────────────────────────────────────────────────────────

set -e  # Exit on any error

# Configuration
EC2_HOST="${EC2_HOST:-ec2-user@your-ec2-ip}"
DOCKER_IMAGE="kaushikkatta/tradevision-api"
BUILD_TAG="${BUILD_NUMBER:-latest}"
APP_PORT=8080
HEALTH_ENDPOINT="http://localhost:${APP_PORT}/actuator/health"
MAX_HEALTH_RETRIES=12
HEALTH_RETRY_INTERVAL=10

log() { echo "[$(date '+%H:%M:%S')] $1"; }
error() { echo "[ERROR] $1" >&2; exit 1; }

# ── Step 1: Pull latest image on EC2 ──────────────────────────
log "Pulling image: ${DOCKER_IMAGE}:${BUILD_TAG}"
ssh "${EC2_HOST}" "docker pull ${DOCKER_IMAGE}:${BUILD_TAG}" || \
    error "Failed to pull Docker image"

# ── Step 2: Stop existing container (if running) ──────────────
log "Stopping existing container..."
ssh "${EC2_HOST}" "docker stop tv-api 2>/dev/null || true"
ssh "${EC2_HOST}" "docker rm tv-api 2>/dev/null || true"

# ── Step 3: Start new container ───────────────────────────────
log "Starting new container: build ${BUILD_TAG}"
ssh "${EC2_HOST}" "docker run -d \
    --name tv-api \
    --restart unless-stopped \
    --network tradevision-network \
    -p ${APP_PORT}:8080 \
    -e SPRING_DATASOURCE_URL=\${DB_URL} \
    -e SPRING_DATASOURCE_USERNAME=\${DB_USER} \
    -e SPRING_DATASOURCE_PASSWORD=\${DB_PASS} \
    -e SPRING_DATA_REDIS_HOST=\${REDIS_HOST} \
    -e SPRING_KAFKA_BOOTSTRAP_SERVERS=\${KAFKA_BROKERS} \
    -e JWT_SECRET=\${JWT_SECRET} \
    -e AWS_REGION=us-east-1 \
    -e SPRING_PROFILES_ACTIVE=prod \
    --memory=512m \
    --cpus=0.5 \
    ${DOCKER_IMAGE}:${BUILD_TAG}"

# ── Step 4: Health check with retry ───────────────────────────
log "Waiting for application health..."
retries=0
while [ $retries -lt $MAX_HEALTH_RETRIES ]; do
    HTTP_CODE=$(ssh "${EC2_HOST}" \
        "curl -s -o /dev/null -w '%{http_code}' ${HEALTH_ENDPOINT}" 2>/dev/null)

    if [ "$HTTP_CODE" = "200" ]; then
        log "✅ Health check PASSED — HTTP 200"
        break
    fi

    retries=$((retries + 1))
    log "Attempt ${retries}/${MAX_HEALTH_RETRIES} — HTTP ${HTTP_CODE}, retrying in ${HEALTH_RETRY_INTERVAL}s..."
    sleep $HEALTH_RETRY_INTERVAL
done

if [ $retries -eq $MAX_HEALTH_RETRIES ]; then
    log "❌ Health check FAILED — rolling back to previous image"
    ssh "${EC2_HOST}" "docker stop tv-api && docker rm tv-api"
    ssh "${EC2_HOST}" "docker run -d --name tv-api ${DOCKER_IMAGE}:previous"
    error "Deployment failed — rollback complete"
fi

# ── Step 5: Cleanup old images ────────────────────────────────
log "Cleaning up old Docker images..."
ssh "${EC2_HOST}" "docker image prune -f"

log "🚀 Deployment complete — ${DOCKER_IMAGE}:${BUILD_TAG} is live"
