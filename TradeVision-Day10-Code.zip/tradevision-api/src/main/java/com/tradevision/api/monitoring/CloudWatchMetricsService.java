package com.tradevision.api.monitoring;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.cloudwatch.CloudWatchClient;
import software.amazon.awssdk.services.cloudwatch.model.*;
import java.time.Instant;
import java.util.List;

/**
 * CloudWatchMetricsService — Day 9 TradeVision
 *
 * WHAT IS CLOUDWATCH?
 * AWS CloudWatch = centralised monitoring, logging, and alerting.
 * Collects metrics from EC2, RDS, and custom application metrics.
 * We use it to track TradeVision-specific business metrics:
 * - API requests per minute
 * - Kafka events processed
 * - Active portfolio count
 * - Cache hit rate
 *
 * WHY CUSTOM METRICS vs just EC2 defaults?
 * EC2 default: CPU%, memory, disk. Infrastructure-level only.
 * Custom: "how many trades executed this minute?"
 *   That's a business metric. It tells you if the platform is
 *   working correctly, not just if the server is alive.
 *
 * WHY @Scheduled every 60 seconds?
 * CloudWatch standard resolution = 1 minute.
 * High-resolution = 1 second (10x cost).
 * For TradeVision, 1-minute granularity is sufficient.
 * In production financial systems, we'd use high-resolution
 * for latency metrics but standard for business metrics.
 *
 * ALARMS WE SET UP:
 * - API error rate > 5%  → PagerDuty alert
 * - Kafka lag > 1000 msg → Engineering Slack channel
 * - DB connection pool > 80% → Auto-scale trigger
 * - EC2 CPU > 70%        → Auto-scale trigger
 */
@Service
public class CloudWatchMetricsService {

    private static final Logger log = LoggerFactory.getLogger(CloudWatchMetricsService.class);
    private static final String NAMESPACE = "TradeVision/Application";

    @Value("${aws.region:us-east-1}")
    private String region;

    private final CloudWatchClient cloudWatchClient;

    // In-memory counters (reset each minute)
    private volatile long apiRequestCount = 0;
    private volatile long kafkaEventsConsumed = 0;
    private volatile long apiErrorCount = 0;
    private volatile long cacheHits = 0;
    private volatile long cacheMisses = 0;

    public CloudWatchMetricsService(CloudWatchClient cloudWatchClient) {
        this.cloudWatchClient = cloudWatchClient;
    }

    // Called by controllers to increment counters
    public void recordApiRequest() { apiRequestCount++; }
    public void recordApiError()   { apiErrorCount++; }
    public void recordKafkaEvent() { kafkaEventsConsumed++; }
    public void recordCacheHit()   { cacheHits++; }
    public void recordCacheMiss()  { cacheMisses++; }

    /**
     * Publish metrics to CloudWatch every 60 seconds
     */
    @Scheduled(fixedRate = 60000)
    public void publishMetrics() {
        try {
            double hitRate = (cacheHits + cacheMisses) > 0
                ? (double) cacheHits / (cacheHits + cacheMisses) * 100 : 0;

            List<MetricDatum> metrics = List.of(
                buildMetric("ApiRequestsPerMinute", apiRequestCount, StandardUnit.COUNT),
                buildMetric("ApiErrorsPerMinute",   apiErrorCount,   StandardUnit.COUNT),
                buildMetric("KafkaEventsPerMinute", kafkaEventsConsumed, StandardUnit.COUNT),
                buildMetric("RedisCacheHitRate",    hitRate,         StandardUnit.PERCENT)
            );

            cloudWatchClient.putMetricData(PutMetricDataRequest.builder()
                .namespace(NAMESPACE)
                .metricData(metrics)
                .build());

            log.info("CloudWatch metrics published: requests={} errors={} kafka={} cacheHit={}%",
                apiRequestCount, apiErrorCount, kafkaEventsConsumed,
                String.format("%.1f", hitRate));

            // Reset counters
            apiRequestCount = 0; apiErrorCount = 0;
            kafkaEventsConsumed = 0; cacheHits = 0; cacheMisses = 0;

        } catch (Exception e) {
            log.warn("CloudWatch publish failed (non-critical): {}", e.getMessage());
            // Non-critical — monitoring failure shouldn't break the app
        }
    }

    private MetricDatum buildMetric(String name, double value, StandardUnit unit) {
        return MetricDatum.builder()
            .metricName(name)
            .value(value)
            .unit(unit)
            .timestamp(Instant.now())
            .dimensions(Dimension.builder()
                .name("Environment")
                .value("production")
                .build())
            .build();
    }
}
