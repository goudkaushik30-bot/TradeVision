package com.tradevision.api.health;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.stereotype.Component;
import javax.sql.DataSource;
import java.sql.Connection;

/**
 * ReadinessIndicator — Day 10 TradeVision
 * Checks all dependencies before accepting traffic.
 */
@Component("tradevisionReadiness")
public class ReadinessIndicator implements HealthIndicator {

    private final DataSource dataSource;
    private final RedisConnectionFactory redisConnectionFactory;

    public ReadinessIndicator(DataSource dataSource,
                               RedisConnectionFactory redisConnectionFactory) {
        this.dataSource = dataSource;
        this.redisConnectionFactory = redisConnectionFactory;
    }

    @Override
    public Health health() {
        Health.Builder builder = Health.up();
        boolean allHealthy = true;

        // Check PostgreSQL
        try (Connection conn = dataSource.getConnection()) {
            boolean valid = conn.isValid(3); // 3 second timeout
            builder.withDetail("postgresql", valid ? "UP" : "DOWN");
            if (!valid) allHealthy = false;
        } catch (Exception e) {
            builder.withDetail("postgresql", "DOWN: " + e.getMessage());
            allHealthy = false;
        }

        // Check Redis
        try {
            redisConnectionFactory.getConnection().ping();
            builder.withDetail("redis", "UP");
        } catch (Exception e) {
            builder.withDetail("redis", "DOWN: " + e.getMessage());
            allHealthy = false;
        }

        return allHealthy ? builder.build() : Health.down().withDetails(
            builder.build().getDetails()).build();
    }
}
