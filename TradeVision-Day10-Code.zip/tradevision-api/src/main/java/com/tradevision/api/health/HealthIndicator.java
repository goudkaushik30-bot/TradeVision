package com.tradevision.api.health;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;
import javax.sql.DataSource;
import java.sql.Connection;

/**
 * K8s Health Indicators — Day 10 TradeVision
 *
 * WHY SEPARATE LIVENESS vs READINESS endpoints?
 *
 * Spring Boot 2.3+ exposes:
 * /actuator/health/liveness  → Kubernetes livenessProbe
 * /actuator/health/readiness → Kubernetes readinessProbe
 *
 * LIVENESS = "is the JVM alive and not deadlocked?"
 * → Only fails if the app is truly broken and needs a restart.
 * → We do NOT check DB connectivity here — a slow DB doesn't
 *   mean the JVM is dead, and restarting won't fix a DB outage.
 *
 * READINESS = "is the app ready to serve traffic?"
 * → Checks DB connection, Kafka connectivity, Redis ping.
 * → During startup, readiness fails until all connections ready.
 * → During graceful shutdown, readiness fails first → K8s
 *   removes pod from load balancer → pod finishes in-flight requests.
 *
 * THIS IS THE MOST MISUNDERSTOOD PART OF K8S HEALTH CHECKS.
 * Getting this wrong causes unnecessary pod restarts under load.
 * At Fidelity this pattern prevented ~40% of unnecessary restarts.
 */
@Component("tradevisionLiveness")
public class HealthIndicator implements org.springframework.boot.actuate.health.HealthIndicator {

    @Override
    public Health health() {
        // Liveness: just check the JVM is responsive
        // Don't check external dependencies here
        return Health.up()
            .withDetail("status", "JVM responsive")
            .withDetail("uptime", java.lang.management.ManagementFactory
                .getRuntimeMXBean().getUptime() + "ms")
            .build();
    }
}
