package com.tradevision.repository;

import com.tradevision.repository.entity.StockPrice;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * DynamicStockQueryRepository — Day 11 TradeVision
 *
 * WHY JPA Criteria API for dynamic queries?
 *
 * When I was in the SoftwareSchool course on Dynamic Queries,
 * the instructor showed two approaches:
 *   1. Build query string by concatenating "WHERE" clauses (string concatenation)
 *   2. Use JPA Criteria API (type-safe, refactor-friendly)
 *
 * String concatenation: fast to write, horrible to maintain.
 * I've seen this in old Fidelity codebases — a 200-line method
 * building a SQL string with dozens of if-statements.
 * One wrong space and the query breaks. No compiler help.
 *
 * Criteria API: more verbose, but:
 *   - Compiler catches mistakes at build time
 *   - Refactoring field names works correctly
 *   - No SQL injection risk
 *   - Works with any combination of filters
 *
 * At Fidelity, in the Geneva Adapter, dynamic queries are used
 * for the pricing DQ check — the WHERE clause changes depending
 * on whether it's month-end (all securities) or daily (new buys only).
 * Same principle here in TradeVision.
 *
 * WHAT THIS ENABLES:
 * The stock screener feature — users filter stocks by:
 *   - Price range (min/max)
 *   - Change percent (positive/negative)
 *   - Volume above threshold
 *   - Any combination of the above
 * Without dynamic queries, we'd need a separate method for every
 * possible combination — 2^3 = 8 methods for 3 optional filters.
 * With Criteria API: one method handles all 8 combinations.
 */
@Repository
public class DynamicStockQueryRepository {

    @Autowired
    private EntityManager entityManager;

    /**
     * Stock screener — filter by any combination of parameters.
     * All parameters are optional (null = no filter applied).
     */
    public List<StockPrice> findStocksByFilters(
            BigDecimal minPrice,
            BigDecimal maxPrice,
            BigDecimal minChangePercent,
            BigDecimal maxChangePercent,
            Long minVolume,
            LocalDateTime from) {

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<StockPrice> query = cb.createQuery(StockPrice.class);
        Root<StockPrice> root = query.from(StockPrice.class);

        List<Predicate> predicates = new ArrayList<>();

        // Only add predicates for non-null parameters
        // This is the key pattern for dynamic queries
        if (minPrice != null) {
            predicates.add(cb.greaterThanOrEqualTo(
                root.get("currentPrice"), minPrice));
        }
        if (maxPrice != null) {
            predicates.add(cb.lessThanOrEqualTo(
                root.get("currentPrice"), maxPrice));
        }
        if (minChangePercent != null) {
            predicates.add(cb.greaterThanOrEqualTo(
                root.get("changePercent"), minChangePercent));
        }
        if (maxChangePercent != null) {
            predicates.add(cb.lessThanOrEqualTo(
                root.get("changePercent"), maxChangePercent));
        }
        if (minVolume != null) {
            predicates.add(cb.greaterThanOrEqualTo(
                root.get("volume"), minVolume));
        }
        if (from != null) {
            predicates.add(cb.greaterThanOrEqualTo(
                root.get("recordedAt"), from));
        }

        // Only latest price per ticker — subquery approach
        // same as the pricing DQ check: get most recent snapshot
        query.where(predicates.toArray(new Predicate[0]))
             .orderBy(cb.desc(root.get("changePercent")));

        TypedQuery<StockPrice> typedQuery =
            entityManager.createQuery(query);
        typedQuery.setMaxResults(50); // safety limit

        return typedQuery.getResultList();
    }
}
