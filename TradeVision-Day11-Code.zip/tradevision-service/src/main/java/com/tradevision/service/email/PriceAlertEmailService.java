package com.tradevision.service.email;

import com.tradevision.repository.PriceAlertRepository;
import com.tradevision.repository.entity.PriceAlert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * PriceAlertEmailService — Day 11 TradeVision
 *
 * THIS IS DIRECTLY INSPIRED BY FFIOPGS-2187:
 * That Jira story was about distributing Geneva reports via email.
 * The team evaluated 3 options (I was in that refinement meeting):
 *   Option 1: Use Geneva's built-in SMTP (deprecated, risky)
 *   Option 2: Build a job in Geneva Adapter to email reports (chosen)
 *   Option 3: Build a full "GREP" platform (too much scope)
 *
 * For TradeVision, we chose the same pattern as Option 2:
 * a simple, focused email job for a specific purpose.
 * We don't need an entire email platform — just price alerts.
 *
 * WHY JavaMailSender over other options?
 * Spring Boot auto-configures JavaMailSender from application.yml.
 * It handles connection pooling, retry, timeout configuration.
 * For complex templated emails we'd use Thymeleaf + MimeMessage.
 * For simple text alerts like this, SimpleMailMessage is enough.
 *
 * WHY NOT send emails directly from Kafka consumer?
 * The Kafka consumer should do ONE thing: process the event and
 * update the database. Email sending is a side effect that:
 *   - Can fail independently (SMTP server down)
 *   - Should not block Kafka offset acknowledgment
 *   - Should be retried on its own schedule
 * Separating concerns = each piece can fail and recover independently.
 * This is the lesson from FFIOPGS-2187 refinement discussions.
 */
@Service
public class PriceAlertEmailService {

    private static final Logger log = LoggerFactory.getLogger(PriceAlertEmailService.class);

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private PriceAlertRepository alertRepository;

    @Value("${app.email.from:tradevision@noreply.com}")
    private String fromEmail;

    /**
     * Send email notification for triggered price alert.
     *
     * WHY we pass the alert object rather than individual fields:
     * If we change the PriceAlert entity later, we don't need to
     * update this method signature. The caller just passes the whole
     * object. This is a design principle I picked up from code reviews
     * at Fidelity — keep method signatures stable.
     */
    public void sendAlertTriggeredEmail(PriceAlert alert, String userEmail) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(userEmail);
            message.setSubject(buildSubject(alert));
            message.setText(buildBody(alert));

            mailSender.send(message);

            log.info("Price alert email sent — userId={} ticker={} type={} to={}",
                alert.getUserId(), alert.getTicker(),
                alert.getAlertType(), userEmail);

        } catch (Exception e) {
            // Log and continue — email failure should not affect core alert processing
            // In production: route to a retry queue
            log.error("Failed to send alert email for userId={} ticker={}: {}",
                alert.getUserId(), alert.getTicker(), e.getMessage());
        }
    }

    /**
     * Send daily price summary for user's portfolio.
     * Equivalent to the daily FDAM report distribution in FFIOPGS-2187.
     */
    public void sendDailyPortfolioSummary(Long userId,
                                           String userEmail,
                                           String summaryText) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(userEmail);
            message.setSubject("TradeVision Daily Portfolio Summary");
            message.setText(summaryText);

            mailSender.send(message);
            log.info("Daily summary email sent to userId={}", userId);

        } catch (Exception e) {
            log.error("Failed to send daily summary to userId={}: {}",
                userId, e.getMessage());
        }
    }

    private String buildSubject(PriceAlert alert) {
        return String.format("TradeVision Alert: %s %s $%.2f",
            alert.getTicker(),
            "ABOVE".equals(alert.getAlertType()) ? "crossed above" : "dropped below",
            alert.getThresholdPrice());
    }

    private String buildBody(PriceAlert alert) {
        return String.format(
            "Your price alert has triggered.\n\n" +
            "Stock: %s (%s)\n" +
            "Alert Type: %s\n" +
            "Your Threshold: $%.4f\n" +
            "Triggered At: $%.4f\n\n" +
            "Login to TradeVision to view your portfolio.\n\n" +
            "— TradeVision Alerts",
            alert.getTicker(),
            alert.getCompanyName(),
            alert.getAlertType(),
            alert.getThresholdPrice(),
            alert.getTriggeredAtPrice()
        );
    }
}
