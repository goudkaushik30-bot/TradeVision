package com.tradevision.service.pricing;

import com.tradevision.repository.StockPriceRepository;
import com.tradevision.repository.entity.StockPrice;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;

/**
 * PricingDQService — Day 11 TradeVision
 *
 * THIS IS DIRECTLY INSPIRED BY REAL WORK:
 * At Fidelity, I worked on FFIOPGS-2590 — "Update Pricing DQ Check"
 * The business requirement was:
 *   - Run comprehensive missing price check ONLY on last business day of month
 *   - Run New Buy missing price check EVERY day
 *
 * The exact same logic is implemented here for TradeVision.
 * When I was building this at Fidelity, the tricky part was:
 * "what is the last business day of the month?"
 * — it's not simply the last calendar day
 * — weekends don't count, and neither do holidays
 * — we had to check: if month-end falls on Saturday, last biz day = Friday
 * — if it falls on Sunday, last biz day = Friday
 *
 * WHY SCHEDULE-BASED DQ checks?
 * In financial systems, data quality is not optional.
 * A missing price means a fund's NAV cannot be calculated.
 * A wrong price means investors are misreported.
 * We run DQ checks to catch problems BEFORE they reach fund accountants.
 *
 * WHY TWO DIFFERENT FREQUENCIES?
 * New Buy check runs daily because new securities added today
 * need prices TODAY — if we wait until month-end, it's too late.
 * Comprehensive check runs monthly because it scans ALL holdings
 * across ALL funds — expensive operation, not needed daily.
 *
 * This is exactly the distinction in acceptance criteria AC1 and AC2
 * of the real Jira story I worked on.
 */
@Service
public class PricingDQService {

    private static final Logger log = LoggerFactory.getLogger(PricingDQService.class);

    @Autowired
    private StockPriceRepository stockPriceRepository;

    /**
     * New Buy missing price check — runs EVERY DAY
     * WHY: New securities added today need prices today.
     * If a trader buys a new stock and there's no price,
     * the portfolio value is wrong immediately.
     */
    @Scheduled(cron = "0 0 18 * * MON-FRI") // 6 PM weekdays
    public void runDailyNewBuyPriceDQCheck() {
        log.info("Running Daily New Buy Price DQ Check — {}", LocalDateTime.now());

        List<String> missingNewBuyPrices = findNewBuysWithMissingPrices();

        if (!missingNewBuyPrices.isEmpty()) {
            log.warn("PRICING DQ ALERT: {} new buy securities missing prices: {}",
                missingNewBuyPrices.size(), missingNewBuyPrices);
            // In production: send alert to fund accountants
            // At Fidelity this would trigger a ServiceNow ticket
        } else {
            log.info("Daily New Buy Price DQ Check PASSED — all new buys have prices");
        }
    }

    /**
     * Comprehensive missing price check — runs ONLY on last business day of month
     *
     * WHY ONLY LAST BUSINESS DAY?
     * Running this daily across all holdings for all funds
     * is an expensive database operation.
     * Month-end is when NAV calculations happen.
     * Fund accountants need complete price data for month-end close.
     * Running it daily would create noise — some prices are expected
     * to be missing mid-month for certain security types.
     *
     * HOW WE DETERMINE LAST BUSINESS DAY:
     * 1. Get last calendar day of current month
     * 2. If Saturday → go back 1 day (Friday)
     * 3. If Sunday → go back 2 days (Friday)
     * 4. Compare with today
     * This does NOT account for holidays — in production at Fidelity
     * we had a holiday calendar table in the database.
     */
    @Scheduled(cron = "0 0 17 * * MON-FRI") // 5 PM weekdays
    public void runComprehensivePriceDQCheck() {
        if (!isLastBusinessDayOfMonth()) {
            log.debug("Skipping comprehensive DQ check — not last business day of month");
            return;
        }

        log.info("Running Comprehensive Price DQ Check (Last Business Day) — {}",
            LocalDateTime.now());

        List<StockPrice> allLatestPrices = stockPriceRepository.findLatestPricesForAllTickers();

        List<String> missingPrices = new ArrayList<>();
        List<String> stalePrices   = new ArrayList<>();  // price > 3 days old

        for (StockPrice price : allLatestPrices) {
            if (price.getCurrentPrice() == null ||
                price.getCurrentPrice().compareTo(BigDecimal.ZERO) == 0) {
                missingPrices.add(price.getTicker());
            }
            if (price.getRecordedAt().isBefore(
                    LocalDateTime.now().minusDays(3))) {
                stalePrices.add(price.getTicker());
            }
        }

        if (!missingPrices.isEmpty() || !stalePrices.isEmpty()) {
            log.error("MONTH-END PRICING DQ FAILED — Missing: {} | Stale: {}",
                missingPrices, stalePrices);
        } else {
            log.info("Month-End Comprehensive Price DQ Check PASSED — {} securities checked",
                allLatestPrices.size());
        }
    }

    /**
     * Determine if today is the last business day of the current month.
     *
     * Real-world note: At Fidelity this logic lived in a shared utility
     * class used across multiple services. Getting this wrong once
     * caused a DQ check to not run on month-end — that was a production
     * incident. The fix was adding an explicit test for this method.
     * Lesson learned: always unit test date logic.
     */
    public boolean isLastBusinessDayOfMonth() {
        LocalDate today = LocalDate.now();
        LocalDate lastCalendarDay = YearMonth.from(today).atEndOfMonth();

        // Walk back from last calendar day to find last business day
        LocalDate lastBizDay = lastCalendarDay;
        while (lastBizDay.getDayOfWeek() == DayOfWeek.SATURDAY ||
               lastBizDay.getDayOfWeek() == DayOfWeek.SUNDAY) {
            lastBizDay = lastBizDay.minusDays(1);
        }

        return today.equals(lastBizDay);
    }

    private List<String> findNewBuysWithMissingPrices() {
        // In production: query for securities bought today with no price
        // For TradeVision: check tickers added in last 24 hours
        return new ArrayList<>(); // placeholder
    }
}
